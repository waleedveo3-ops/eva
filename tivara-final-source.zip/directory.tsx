"use client";
import Link from "next/link";
import { useState } from "react";
import {
  ArrowLeft,
  MapPin,
  Search,
  SlidersHorizontal,
  Star,
} from "lucide-react";
import { providers, services, titles, type DirectoryKind } from "@/lib/beauty";
import { ServiceIcon } from "./service-icon";
import { Breadcrumb } from "./trail";
const intros = {
  services: [
    "عناية تناسبكِ",
    "من لمسات الشعر إلى عناية البشرة، قارني الخدمات والأسعار واختاري ما يناسبكِ.",
    "/service-5.webp",
  ],
  salons: [
    "أماكن تستحق الاكتشاف",
    "استكشفي صالونات الرياض وجدة حسب الحي والخدمة التي تبحثين عنها.",
    "/salons0.webp",
  ],
  experts: [
    "لمسات احترافية",
    "تعرّفي على خبيرات مستقلات في مدينتكِ واستكشفي تخصصاتهن وأعمالهن.",
    "/experts0.webp",
  ],
};
function SelectFilter({
  label,
  value,
  options,
  change,
}: {
  label: string;
  value: string;
  options: string[];
  change: (s: string) => void;
}) {
  return (
    <label className="bd-field">
      {label}
      <select value={value} onChange={(e) => change(e.target.value)}>
        <option value="">الكل</option>
        {options.map((o) => (
          <option key={o}>{o}</option>
        ))}
      </select>
    </label>
  );
}
export function Directory({
  kind,
  initialCategory,
}: {
  kind: DirectoryKind;
  initialCategory?: string;
}) {
  const [search, S] = useState(""),
    [city, C] = useState(""),
    [area, A] = useState(""),
    [rating, R] = useState(""),
    [category, K] = useState(
      initialCategory && services.includes(initialCategory)
        ? initialCategory
        : "",
    ),
    [sort, T] = useState("default");
  const serviceMode = kind === "services";
  const base = providers.filter((p) => serviceMode || p.kind === kind);
  const rows = base
    .flatMap((p) =>
      (serviceMode ? p.offers : [null]).map((o) => ({
        name: o?.title ?? p.name,
        price: o?.price ?? p.price,
        photo: o?.photo ?? p.photo,
        subtitle: o
          ? p.name
          : "specialty" in p
            ? String(p.specialty)
            : p.offers.map((x) => x.category).join(" · "),
        p,
        o,
      })),
    )
    .filter(
      ({ name, p, o, subtitle }) =>
        (!city || p.city === city) &&
        (!area || p.area === area) &&
        (!category ||
          (o
            ? o.category === category
            : p.offers.some((v) => v.category === category))) &&
        (!rating || +p.rating >= +rating) &&
        [name, p.name, p.city, p.area, subtitle]
          .join(" ")
          .includes(search.trim()),
    )
    .sort((a, b) =>
      sort === "price"
        ? a.price - b.price
        : sort === "rating"
          ? +b.p.rating - Number(a.p.rating)
          : 0,
    );
  const reset = () => {
    S("");
    C("");
    A("");
    R("");
    K("");
    T("default");
  };
  return (
    <>
      <Breadcrumb current={titles[kind]} />
      <section className="bd-banner">
        <div>
          <div className="eyebrow">
            <i />
            {intros[kind][0]}
          </div>
          <h1>{titles[kind]}</h1>
          <p>{intros[kind][1]}</p>
        </div>
        <img src={intros[kind][2]} alt="" />
      </section>
      {serviceMode && (
        <div className="bd-cats" aria-label="فئات الخدمات">
          {services.map((s, i) => (
            <button
              key={s}
              aria-pressed={s === category}
              onClick={() => K(s === category ? "" : s)}
            >
              <ServiceIcon index={i} />
              {s}
            </button>
          ))}
        </div>
      )}
      <section className="bd-body">
        <aside className="bd-panel bd-filters">
          <h3>
            <SlidersHorizontal size={18} />
            تصفية النتائج
          </h3>
          <label className="bd-field">
            البحث
            <div className="bd-search">
              <Search size={16} />
              <input
                type="search"
                placeholder="ابحثي بالاسم…"
                value={search}
                onChange={(e) => S(e.target.value)}
              />
            </div>
          </label>
          <SelectFilter
            label="المدينة"
            value={city}
            options={["الرياض", "جدة"]}
            change={(s) => {
              C(s);
              A("");
            }}
          />
          <SelectFilter
            label="الحي"
            value={area}
            options={[
              ...new Set(
                base.filter((p) => !city || p.city === city).map((p) => p.area),
              ),
            ]}
            change={A}
          />
          {!serviceMode && (
            <SelectFilter
              label={kind === "experts" ? "التخصص" : "الخدمة"}
              value={category}
              options={services.filter((s) =>
                base.some((p) => p.offers.some((o) => o.category === s)),
              )}
              change={K}
            />
          )}
          <SelectFilter
            label="الحد الأدنى للتقييم"
            value={rating}
            options={["4.7", "4.8", "4.9"]}
            change={R}
          />
          <button className="textlink" onClick={reset}>
            إعادة ضبط الفلاتر
          </button>
        </aside>
        <div>
          <div className="bd-results">
            <h2>
              {serviceMode
                ? "الخدمات المتاحة"
                : kind === "salons"
                  ? "الصالونات"
                  : "الخبيرات"}{" "}
              <small aria-live="polite">{rows.length}</small>
            </h2>
            <select
              aria-label="ترتيب النتائج"
              value={sort}
              onChange={(e) => T(e.target.value)}
            >
              <option value="default">الترتيب الافتراضي</option>
              <option value="price">السعر: الأقل أولًا</option>
              <option value="rating">الأعلى تقييمًا</option>
            </select>
          </div>
          <p className="bd-caption">
            دليل توضيحي · الأسماء والتقييمات والأسعار للمعاينة فقط.
          </p>
          <div className="bd-grid">
            {rows.map(({ name, price, photo, subtitle, p, o }) => (
              <Link
                key={p.href + name}
                className="salon bd-card"
                href={p.href + (o ? "#menu" : "")}
              >
                <div className="salonphoto">
                  <img src={photo} loading="lazy" alt="" />
                  <span className="rating">
                    <Star size={13} fill="currentColor" />
                    <b>{p.rating}</b>
                  </span>
                </div>
                <div className="cardbody">
                  <p>
                    <MapPin size={13} />
                    {p.city} · {p.area}
                  </p>
                  <h3>{name}</h3>
                  <p>{subtitle}</p>
                  <div className="cardbottom">
                    <span>
                      {o ? "السعر" : "يبدأ من"} <b>{price} ر.س</b>
                    </span>
                    <span className="circlelink">
                      <ArrowLeft size={16} />
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
          {!rows.length && (
            <div className="bd-panel">
              <h3>لا توجد نتائج مطابقة</h3>
              <p>غيّري أحد الفلاتر أو ابدئي بحثًا جديدًا.</p>
              <button className="textlink" onClick={reset}>
                عرض جميع النتائج
              </button>
            </div>
          )}
        </div>
      </section>
    </>
  );
}
