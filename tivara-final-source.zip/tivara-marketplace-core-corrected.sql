-- TIVARA marketplace core migration
-- Additive migration: preserves existing profiles, salon_profiles, expert_profiles,
-- expert_documents and admin_users. Review and test in a staging project first.
-- Booking creation is performed through public.create_booking(), not direct table inserts.
begin;

create extension if not exists pgcrypto;
create extension if not exists btree_gist;

-- ---------------------------------------------------------------------------
-- 1. Catalog
-- ---------------------------------------------------------------------------
create table if not exists public.service_categories (
  id uuid primary key default gen_random_uuid(),
  name_ar text not null,
  name_en text,
  slug text not null unique,
  description text,
  image_url text,
  sort_order integer not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  category_id uuid references public.service_categories(id) on delete set null,
  provider_type text not null check (provider_type in ('salon','independent_expert')),
  salon_owner_id uuid references public.profiles(id) on delete cascade,
  expert_owner_id uuid references public.profiles(id) on delete cascade,
  name_ar text not null,
  name_en text,
  description text,
  duration_minutes integer not null check (duration_minutes between 5 and 720),
  price numeric(10,2) not null check (price >= 0),
  deposit_amount numeric(10,2) not null default 0
    check (deposit_amount >= 0 and deposit_amount <= price),
  in_salon_enabled boolean not null default false,
  home_service_enabled boolean not null default false,
  travel_fee numeric(10,2) not null default 0 check (travel_fee >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint services_owner_type_check check (
    (provider_type = 'salon' and salon_owner_id is not null
      and expert_owner_id is null and in_salon_enabled = true)
    or
    (provider_type = 'independent_expert' and expert_owner_id is not null
      and salon_owner_id is null and in_salon_enabled = false
      and home_service_enabled = true)
  )
);
create index if not exists services_category_active_idx
  on public.services(category_id, is_active);
create index if not exists services_salon_owner_idx
  on public.services(salon_owner_id) where salon_owner_id is not null;
create index if not exists services_expert_owner_idx
  on public.services(expert_owner_id) where expert_owner_id is not null;

-- ---------------------------------------------------------------------------
-- 2. Salon branches, staff and staff/service assignments
-- ---------------------------------------------------------------------------
create table if not exists public.salon_branches (
  id uuid primary key default gen_random_uuid(),
  salon_owner_id uuid not null references public.profiles(id) on delete cascade,
  branch_name text not null,
  city text not null,
  district text,
  address text not null,
  latitude numeric(10,7),
  longitude numeric(10,7),
  phone text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (id, salon_owner_id)
);
create index if not exists salon_branches_owner_idx
  on public.salon_branches(salon_owner_id);

create table if not exists public.salon_staff (
  id uuid primary key default gen_random_uuid(),
  salon_owner_id uuid not null references public.profiles(id) on delete cascade,
  branch_id uuid not null,
  full_name text not null,
  phone text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  constraint salon_staff_branch_owner_fk
    foreign key (branch_id, salon_owner_id)
    references public.salon_branches(id, salon_owner_id) on delete cascade,
  unique (id, salon_owner_id)
);
create index if not exists salon_staff_branch_idx on public.salon_staff(branch_id);
create index if not exists salon_staff_owner_idx on public.salon_staff(salon_owner_id);

create table if not exists public.staff_services (
  staff_id uuid not null references public.salon_staff(id) on delete cascade,
  service_id uuid not null references public.services(id) on delete cascade,
  primary key (staff_id, service_id)
);

-- ---------------------------------------------------------------------------
-- 3. Availability and time off
-- weekday: 0 Sunday ... 6 Saturday. Times use Asia/Riyadh when booking.
-- ---------------------------------------------------------------------------
create table if not exists public.provider_availability (
  id uuid primary key default gen_random_uuid(),
  provider_type text not null check (provider_type in ('salon_staff','independent_expert')),
  staff_id uuid references public.salon_staff(id) on delete cascade,
  expert_owner_id uuid references public.profiles(id) on delete cascade,
  branch_id uuid references public.salon_branches(id) on delete cascade,
  weekday smallint not null check (weekday between 0 and 6),
  start_time time not null,
  end_time time not null,
  service_location text not null check (service_location in ('in_salon','at_customer_home')),
  buffer_minutes integer not null default 0 check (buffer_minutes between 0 and 240),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  constraint availability_time_check check (end_time > start_time),
  constraint availability_provider_check check (
    (provider_type = 'salon_staff' and staff_id is not null
      and expert_owner_id is null and branch_id is not null)
    or
    (provider_type = 'independent_expert' and expert_owner_id is not null
      and staff_id is null and branch_id is null
      and service_location = 'at_customer_home')
  )
);
create index if not exists provider_availability_staff_idx
  on public.provider_availability(staff_id, weekday, service_location)
  where is_active;
create index if not exists provider_availability_expert_idx
  on public.provider_availability(expert_owner_id, weekday)
  where is_active;

create table if not exists public.provider_time_off (
  id uuid primary key default gen_random_uuid(),
  provider_type text not null check (provider_type in ('salon_staff','independent_expert')),
  staff_id uuid references public.salon_staff(id) on delete cascade,
  expert_owner_id uuid references public.profiles(id) on delete cascade,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  reason text,
  created_at timestamptz not null default now(),
  constraint time_off_range_check check (ends_at > starts_at),
  constraint time_off_provider_check check (
    (provider_type = 'salon_staff' and staff_id is not null and expert_owner_id is null)
    or
    (provider_type = 'independent_expert' and expert_owner_id is not null and staff_id is null)
  )
);

-- ---------------------------------------------------------------------------
-- 4. Bookings
-- ---------------------------------------------------------------------------
create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  booking_number bigint generated by default as identity unique,
  customer_id uuid not null references public.profiles(id) on delete restrict,
  service_id uuid not null references public.services(id) on delete restrict,
  provider_type text not null check (provider_type in ('salon_staff','independent_expert')),
  staff_id uuid references public.salon_staff(id) on delete restrict,
  expert_owner_id uuid references public.profiles(id) on delete restrict,
  salon_owner_id uuid references public.profiles(id) on delete restrict,
  branch_id uuid references public.salon_branches(id) on delete restrict,
  service_location text not null check (service_location in ('in_salon','at_customer_home')),
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  buffer_minutes integer not null default 0 check (buffer_minutes between 0 and 240),
  customer_city text,
  customer_district text,
  customer_address text,
  customer_latitude numeric(10,7),
  customer_longitude numeric(10,7),
  service_price numeric(10,2) not null check (service_price >= 0),
  travel_fee numeric(10,2) not null default 0 check (travel_fee >= 0),
  deposit_due numeric(10,2) not null default 0 check (deposit_due >= 0),
  currency char(3) not null default 'SAR' check (currency = 'SAR'),
  status text not null default 'pending_payment'
    check (status in ('pending_payment','confirmed','in_progress','completed',
                      'cancelled','rejected','no_show','expired')),
  customer_notes text,
  cancellation_reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint booking_time_check check (ends_at > starts_at),
  constraint booking_provider_check check (
    (provider_type = 'salon_staff' and staff_id is not null
      and expert_owner_id is null and salon_owner_id is not null)
    or
    (provider_type = 'independent_expert' and expert_owner_id is not null
      and staff_id is null and salon_owner_id is null
      and branch_id is null and service_location = 'at_customer_home')
  ),
  constraint booking_location_check check (
    (service_location = 'in_salon' and branch_id is not null)
    or service_location = 'at_customer_home'
  )
);
create index if not exists bookings_customer_date_idx
  on public.bookings(customer_id, starts_at desc);
create index if not exists bookings_status_date_idx
  on public.bookings(status, starts_at);
create index if not exists bookings_salon_date_idx
  on public.bookings(salon_owner_id, starts_at desc);
create index if not exists bookings_staff_date_idx
  on public.bookings(staff_id, starts_at desc);
create index if not exists bookings_expert_date_idx
  on public.bookings(expert_owner_id, starts_at desc);

-- Exclusion constraints prevent overlapping live reservations, including buffer.
do $migration$
begin
  alter table public.bookings
    add constraint bookings_staff_no_overlap
    exclude using gist (
      staff_id with =,
      tstzrange(starts_at, ends_at + make_interval(mins => buffer_minutes), '[)') with &&
    )
    where (staff_id is not null and status in ('pending_payment','confirmed','in_progress'));
exception when duplicate_object then null;
end
$migration$;

do $migration$
begin
  alter table public.bookings
    add constraint bookings_expert_no_overlap
    exclude using gist (
      expert_owner_id with =,
      tstzrange(starts_at, ends_at + make_interval(mins => buffer_minutes), '[)') with &&
    )
    where (expert_owner_id is not null and status in ('pending_payment','confirmed','in_progress'));
exception when duplicate_object then null;
end
$migration$;

-- ---------------------------------------------------------------------------
-- 5. Payments and commissions
-- Provider payload is deliberately not stored in the customer-readable table.
-- Store raw webhook payloads in a server-only system/log, never expose them to clients.
-- ---------------------------------------------------------------------------
create table if not exists public.payment_records (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id) on delete restrict,
  customer_id uuid not null references public.profiles(id) on delete restrict,
  provider_name text not null default 'streampay',
  provider_reference text unique,
  payment_link text,
  amount numeric(10,2) not null check (amount > 0),
  currency char(3) not null default 'SAR' check (currency = 'SAR'),
  status text not null default 'pending'
    check (status in ('pending','paid','failed','cancelled','refunded','partially_refunded')),
  verified_at timestamptz,
  webhook_event_id text unique,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists payment_records_booking_idx on public.payment_records(booking_id);
create index if not exists payment_records_customer_idx on public.payment_records(customer_id, created_at desc);

create table if not exists public.commission_rules (
  id uuid primary key default gen_random_uuid(),
  provider_type text not null check (provider_type in ('salon','independent_expert')),
  commission_percent numeric(5,2) not null check (commission_percent between 0 and 100),
  starts_at timestamptz not null default now(),
  ends_at timestamptz,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  constraint commission_rule_dates check (ends_at is null or ends_at > starts_at)
);

create table if not exists public.commission_entries (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null unique references public.bookings(id) on delete restrict,
  provider_owner_id uuid not null references public.profiles(id) on delete restrict,
  gross_amount numeric(10,2) not null check (gross_amount >= 0),
  commission_percent numeric(5,2) not null check (commission_percent between 0 and 100),
  commission_amount numeric(10,2) not null check (commission_amount >= 0),
  provider_net_amount numeric(10,2) not null check (provider_net_amount >= 0),
  status text not null default 'pending' check (status in ('pending','payable','paid','reversed')),
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- 6. Promotions, reviews, notifications and administration
-- ---------------------------------------------------------------------------
create table if not exists public.coupons (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  description text,
  discount_type text not null check (discount_type in ('percentage','fixed')),
  discount_value numeric(10,2) not null check (discount_value > 0),
  max_discount numeric(10,2) check (max_discount is null or max_discount >= 0),
  min_order_amount numeric(10,2) not null default 0 check (min_order_amount >= 0),
  starts_at timestamptz,
  ends_at timestamptz,
  usage_limit integer check (usage_limit is null or usage_limit > 0),
  usage_count integer not null default 0 check (usage_count >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  constraint coupon_dates check (ends_at is null or starts_at is null or ends_at > starts_at)
);

create table if not exists public.coupon_redemptions (
  id uuid primary key default gen_random_uuid(),
  coupon_id uuid not null references public.coupons(id) on delete restrict,
  customer_id uuid not null references public.profiles(id) on delete restrict,
  booking_id uuid not null unique references public.bookings(id) on delete restrict,
  discount_amount numeric(10,2) not null check (discount_amount >= 0),
  created_at timestamptz not null default now(),
  unique (coupon_id, customer_id, booking_id)
);

create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null unique references public.bookings(id) on delete restrict,
  customer_id uuid not null references public.profiles(id) on delete restrict,
  salon_owner_id uuid references public.profiles(id) on delete set null,
  expert_owner_id uuid references public.profiles(id) on delete set null,
  rating smallint not null check (rating between 1 and 5),
  comment text,
  moderation_status text not null default 'pending'
    check (moderation_status in ('pending','published','hidden','rejected')),
  admin_note text,
  created_at timestamptz not null default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  body text not null,
  notification_type text not null default 'general',
  data jsonb not null default '{}'::jsonb,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists notifications_user_date_idx
  on public.notifications(user_id, created_at desc);

create table if not exists public.platform_settings (
  key text primary key,
  value jsonb not null,
  description text,
  updated_by uuid references auth.users(id) on delete set null,
  updated_at timestamptz not null default now()
);

create table if not exists public.admin_audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references auth.users(id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id text,
  old_values jsonb,
  new_values jsonb,
  created_at timestamptz not null default now()
);
create index if not exists admin_audit_logs_date_idx
  on public.admin_audit_logs(created_at desc);
create index if not exists admin_audit_logs_actor_idx
  on public.admin_audit_logs(actor_id, created_at desc);

-- ---------------------------------------------------------------------------
-- 7. Granular admin role helper. Super Admin bypasses all listed role checks.
-- ---------------------------------------------------------------------------
create or replace function public.has_admin_role(allowed_roles text[])
returns boolean
language sql
stable
security definer
set search_path = ''
as $function$
  select exists (
    select 1
    from public.admin_users a
    where a.user_id = (select auth.uid())
      and a.is_active = true
      and (a.role = 'super_admin' or a.role = any(allowed_roles))
  );
$function$;

revoke all on function public.has_admin_role(text[]) from public;
grant execute on function public.has_admin_role(text[]) to authenticated;

-- ---------------------------------------------------------------------------
-- 8. RLS and policies. Drop exact policy names first so reruns are predictable.
-- ---------------------------------------------------------------------------
do $rls$
declare t text;
begin
  foreach t in array array[
    'service_categories','services','salon_branches','salon_staff','staff_services',
    'provider_availability','provider_time_off','bookings','payment_records',
    'commission_rules','commission_entries','coupons','coupon_redemptions',
    'reviews','notifications','platform_settings','admin_audit_logs'
  ] loop
    execute format('alter table public.%I enable row level security', t);
  end loop;
end
$rls$;

drop policy if exists "Active categories public read" on public.service_categories;
create policy "Active categories public read" on public.service_categories
for select to anon, authenticated
using (is_active or public.has_admin_role(array['operations','reviewer']));

drop policy if exists "Operations manage categories" on public.service_categories;
create policy "Operations manage categories" on public.service_categories
for all to authenticated
using (public.has_admin_role(array['operations']))
with check (public.has_admin_role(array['operations']));

drop policy if exists "Active services public read" on public.services;
create policy "Active services public read" on public.services
for select to anon, authenticated
using (
  is_active
  and (
    (provider_type = 'salon' and exists (
      select 1 from public.salon_profiles sp
      where sp.owner_id = salon_owner_id and sp.status = 'approved'
    ))
    or
    (provider_type = 'independent_expert' and exists (
      select 1 from public.expert_profiles ep
      where ep.owner_id = expert_owner_id and ep.status = 'approved'
    ))
  )
  or public.has_admin_role(array['operations','reviewer'])
  or salon_owner_id = (select auth.uid())
  or expert_owner_id = (select auth.uid())
);

drop policy if exists "Owners manage services" on public.services;
create policy "Owners manage services" on public.services
for all to authenticated
using (
  (salon_owner_id = (select auth.uid()) and provider_type = 'salon')
  or (expert_owner_id = (select auth.uid()) and provider_type = 'independent_expert')
  or public.has_admin_role(array['operations'])
)
with check (
  (salon_owner_id = (select auth.uid()) and provider_type = 'salon')
  or (expert_owner_id = (select auth.uid()) and provider_type = 'independent_expert')
  or public.has_admin_role(array['operations'])
);

drop policy if exists "Salon owners manage branches" on public.salon_branches;
create policy "Salon owners manage branches" on public.salon_branches
for all to authenticated
using (salon_owner_id = (select auth.uid()) or public.has_admin_role(array['operations']))
with check (salon_owner_id = (select auth.uid()) or public.has_admin_role(array['operations']));

drop policy if exists "Salon owners manage staff" on public.salon_staff;
create policy "Salon owners manage staff" on public.salon_staff
for all to authenticated
using (salon_owner_id = (select auth.uid()) or public.has_admin_role(array['operations']))
with check (salon_owner_id = (select auth.uid()) or public.has_admin_role(array['operations']));

drop policy if exists "Staff service links owner access" on public.staff_services;
create policy "Staff service links owner access" on public.staff_services
for all to authenticated
using (
  exists (
    select 1 from public.salon_staff s
    where s.id = staff_id
      and (s.salon_owner_id = (select auth.uid()) or public.has_admin_role(array['operations']))
  )
)
with check (
  exists (
    select 1 from public.salon_staff s
    where s.id = staff_id
      and (s.salon_owner_id = (select auth.uid()) or public.has_admin_role(array['operations']))
  )
);

drop policy if exists "Availability public read" on public.provider_availability;
create policy "Availability public read" on public.provider_availability
for select to anon, authenticated using (is_active);

drop policy if exists "Providers manage availability" on public.provider_availability;
create policy "Providers manage availability" on public.provider_availability
for all to authenticated
using (
  (provider_type = 'salon_staff' and exists (
    select 1 from public.salon_staff s
    where s.id = staff_id and s.salon_owner_id = (select auth.uid())
  ))
  or (provider_type = 'independent_expert' and expert_owner_id = (select auth.uid()))
  or public.has_admin_role(array['operations'])
)
with check (
  (provider_type = 'salon_staff' and exists (
    select 1 from public.salon_staff s
    where s.id = staff_id and s.salon_owner_id = (select auth.uid())
  ))
  or (provider_type = 'independent_expert' and expert_owner_id = (select auth.uid()))
  or public.has_admin_role(array['operations'])
);

drop policy if exists "Providers manage time off" on public.provider_time_off;
create policy "Providers manage time off" on public.provider_time_off
for all to authenticated
using (
  (provider_type = 'salon_staff' and exists (
    select 1 from public.salon_staff s
    where s.id = staff_id and s.salon_owner_id = (select auth.uid())
  ))
  or (provider_type = 'independent_expert' and expert_owner_id = (select auth.uid()))
  or public.has_admin_role(array['operations'])
)
with check (
  (provider_type = 'salon_staff' and exists (
    select 1 from public.salon_staff s
    where s.id = staff_id and s.salon_owner_id = (select auth.uid())
  ))
  or (provider_type = 'independent_expert' and expert_owner_id = (select auth.uid()))
  or public.has_admin_role(array['operations'])
);

-- Bookings are read-only to clients via RLS. Creation/cancellation/payment confirmation
-- must be implemented as validated server-side RPC/Edge Functions.
drop policy if exists "Booking parties read" on public.bookings;
create policy "Booking parties read" on public.bookings
for select to authenticated
using (
  customer_id = (select auth.uid())
  or salon_owner_id = (select auth.uid())
  or expert_owner_id = (select auth.uid())
  or exists (
    select 1 from public.salon_staff s
    where s.id = staff_id and s.salon_owner_id = (select auth.uid())
  )
  or public.has_admin_role(array['operations','reviewer','support','accountant'])
);

drop policy if exists "Customers create own booking" on public.bookings;
drop policy if exists "Booking parties update" on public.bookings;
-- No direct authenticated INSERT/UPDATE policy by design.

drop policy if exists "Payment parties read" on public.payment_records;
create policy "Payment parties read" on public.payment_records
for select to authenticated
using (
  customer_id = (select auth.uid())
  or public.has_admin_role(array['accountant','operations'])
);

drop policy if exists "Finance manages payments" on public.payment_records;
-- Payment rows are written only by trusted server-side service-role code/webhooks.

drop policy if exists "Finance reads commission rules" on public.commission_rules;
create policy "Finance reads commission rules" on public.commission_rules
for select to authenticated
using (public.has_admin_role(array['accountant','operations']));

drop policy if exists "Accountants manage commission rules" on public.commission_rules;
create policy "Accountants manage commission rules" on public.commission_rules
for all to authenticated
using (public.has_admin_role(array['accountant']))
with check (public.has_admin_role(array['accountant']));

drop policy if exists "Providers and finance read commissions" on public.commission_entries;
create policy "Providers and finance read commissions" on public.commission_entries
for select to authenticated
using (
  provider_owner_id = (select auth.uid())
  or public.has_admin_role(array['accountant','operations'])
);

drop policy if exists "Accountants manage commissions" on public.commission_entries;
create policy "Accountants manage commissions" on public.commission_entries
for all to authenticated
using (public.has_admin_role(array['accountant']))
with check (public.has_admin_role(array['accountant']));

drop policy if exists "Active coupons read" on public.coupons;
create policy "Active coupons read" on public.coupons
for select to authenticated using (is_active or public.has_admin_role(array['operations']));

drop policy if exists "Operations manage coupons" on public.coupons;
create policy "Operations manage coupons" on public.coupons
for all to authenticated
using (public.has_admin_role(array['operations']))
with check (public.has_admin_role(array['operations']));

drop policy if exists "Customers read own coupon redemptions" on public.coupon_redemptions;
create policy "Customers read own coupon redemptions" on public.coupon_redemptions
for select to authenticated
using (
  customer_id = (select auth.uid())
  or public.has_admin_role(array['accountant','operations'])
);

drop policy if exists "Published reviews read" on public.reviews;
create policy "Published reviews read" on public.reviews
for select to anon, authenticated
using (
  moderation_status = 'published'
  or customer_id = (select auth.uid())
  or public.has_admin_role(array['reviewer','operations'])
);

drop policy if exists "Customer reviews completed bookings" on public.reviews;
create policy "Customer reviews completed bookings" on public.reviews
for insert to authenticated
with check (
  customer_id = (select auth.uid())
  and exists (
    select 1 from public.bookings b
    where b.id = booking_id
      and b.customer_id = (select auth.uid())
      and b.status = 'completed'
  )
);

drop policy if exists "Reviewers moderate reviews" on public.reviews;
create policy "Reviewers moderate reviews" on public.reviews
for update to authenticated
using (public.has_admin_role(array['reviewer','operations']))
with check (public.has_admin_role(array['reviewer','operations']));

drop policy if exists "Users read own notifications" on public.notifications;
create policy "Users read own notifications" on public.notifications
for select to authenticated
using (user_id = (select auth.uid()) or public.has_admin_role(array['support','operations']));

drop policy if exists "Users update own notifications" on public.notifications;
create policy "Users update own notifications" on public.notifications
for update to authenticated
using (user_id = (select auth.uid()))
with check (user_id = (select auth.uid()));

drop policy if exists "Super admins manage platform settings" on public.platform_settings;
create policy "Super admins manage platform settings" on public.platform_settings
for all to authenticated
using (public.has_admin_role(array[]::text[]))
with check (public.has_admin_role(array[]::text[]));

drop policy if exists "Admins read audit logs" on public.admin_audit_logs;
create policy "Admins read audit logs" on public.admin_audit_logs
for select to authenticated
using (public.has_admin_role(array['operations','reviewer']));

drop policy if exists "Actor inserts audit log" on public.admin_audit_logs;
create policy "Actor inserts audit log" on public.admin_audit_logs
for insert to authenticated
with check (actor_id = (select auth.uid()));

-- ---------------------------------------------------------------------------
-- 9. Grants. RLS is still enforced. Do not grant payment writes to browser clients.
-- ---------------------------------------------------------------------------
grant select on public.service_categories, public.services, public.provider_availability
  to anon, authenticated;

grant select, insert, update, delete on
  public.service_categories, public.services, public.salon_branches, public.salon_staff,
  public.staff_services, public.provider_availability, public.provider_time_off,
  public.bookings, public.commission_rules, public.commission_entries,
  public.coupons, public.coupon_redemptions, public.reviews, public.notifications,
  public.platform_settings, public.admin_audit_logs
  to authenticated;

grant select on public.payment_records to authenticated;
revoke insert, update, delete on public.payment_records from anon, authenticated;

grant usage, select on all sequences in schema public to authenticated;

commit;
