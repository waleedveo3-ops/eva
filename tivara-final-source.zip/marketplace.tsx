"use client";
import { useState, useRef, useEffect } from "react";
import { X } from "lucide-react";
import { Navigation } from "./navigation";
import { Discovery } from "./discovery";
import { Collections, Footer } from "./collections";
import type { Detail } from "@/lib/beauty";
export default function Marketplace({
  children,
}: {
  children?: React.ReactNode;
}) {
  const [detail, setDetail] = useState<Detail | null>(null),
    [ready, setReady] = useState(false);
  const dialog = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    setReady(true);
  }, []);
  useEffect(() => {
    if (detail) {
      dialog.current?.showModal();
      document.body.style.overflow = "hidden";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [detail]);
  return (
    <div data-ready={ready}>
      <Navigation />
      <main className="shell">
        {children ?? (
          <>
            <Discovery />
            <Collections show={setDetail} />
          </>
        )}
      </main>
      <Footer show={setDetail} />
      <dialog
        ref={dialog}
        aria-labelledby="detail-title"
        onClose={() => setDetail(null)}
        onClick={(e) => {
          if (e.target === dialog.current) dialog.current.close();
        }}
      >
        <div className="dialoginner">
          <button
            className="close"
            aria-label="إغلاق"
            onClick={() => dialog.current?.close()}
          >
            <X size={18} />
          </button>
          {detail?.image && <img src={detail.image} alt="" />}
          <div className="eyebrow">تيفارا · معاينة</div>
          <h2 id="detail-title">{detail?.title}</h2>
          <p>{detail?.body}</p>
          {detail?.note && <p className="note">{detail.note}</p>}
          <button className="primary" onClick={() => dialog.current?.close()}>
            متابعة الاستكشاف
          </button>
        </div>
      </dialog>
    </div>
  );
}
