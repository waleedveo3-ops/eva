import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "TIVARA | تيفارا — اكتشفي عالم الجمال",
  description: "دليلك لاكتشاف الصالونات وخبيرات التجميل في الرياض وجدة.",
  icons: { icon: "/lotus.svg" },
};
export const viewport: Viewport = {
  themeColor: "#E6FAF8",
  colorScheme: "light",
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl">
      <body className="antialiased">{children}</body>
    </html>
  );
}
