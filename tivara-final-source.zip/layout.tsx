import Marketplace from "@/components/marketplace";
import "./browse.css";
export default function BrowseLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <Marketplace>{children}</Marketplace>;
}
