"use client";
import { useState } from "react";
import { MapPin, Star, CalendarDays, Clock } from "lucide-react";
import { titles, type Provider } from "@/lib/beauty";
import { Breadcrumb } from "./trail";
export function Profile({ p }: { p: Provider }) {
  const salon = p.kind === "salons";
  const gallery = [
    { src: p.photo, label: p.name },
    ...p.offers.map((o) => ({ src: o.photo, label: o.title })),
  ];
  const [view, V] = useState(0),
    [booking, B] = useState(false),
    [option, O] = useState(0);
  const chosen = p.offers[option];
  return (
    <>
      <Breadcrumb current={p.name} parent={[titles[p.kind], "/" + p.kind]} />
      <div className="profile-grid">
        <section>
          <div className="bd-photos">
            <img
              className="bd-cover"
              alt={gallery[view].label}
              src={gallery[view].src}
            />
            <div className="bd-thumbs">
              {gallery.map((g, i) => (
                <button
                  key={g.src}
                  onClick={() => V(i)}
                  aria-label={"عرض " + g.label}
                  aria-pressed={view === i}
                >
                  <img src={g.src} alt="" />
                </button>
              ))}
            </div>
          </div>
          <div className="bd-panel">
            <div className="eyebrow">
              <i />
              نبذة تعريفية
            </div>
            <h2>{salon ? "عن الصالون" : "عن الخبيرة"}</h2>
            <p>{p.bio}</p>
            <div className="bd-tags">
              {p.offers.map((o) => (
                <span key={o.category}>{o.category}</span>
              ))}
            </div>
          </div>
          <section className="bd-panel" id="menu">
            <h2>الخدمات والأسعار</h2>
            {p.offers.map((o) => (
              <div className="bd-line" key={o.title}>
                <div>
                  <h3>{o.title}</h3>
                  <small>{o.minutes} دقيقة</small>
                </div>
                <b>{o.price} ر.س</b>
              </div>
            ))}
          </section>
          <section className="bd-panel">
            <h2>{salon ? "الفروع وأوقات العمل" : "الموقع وأوقات التوفر"}</h2>
            <p>
              <MapPin size={16} />
              {salon ? "الفرع الرئيسي" : "منطقة تقديم الخدمة"} · {p.city}، حي{" "}
              {p.area}
            </p>
            <p>
              <Clock size={16} />
              {salon
                ? "السبت إلى الخميس · ١٠ صباحًا – ٩ مساءً"
                : "الأحد إلى الخميس · ٢ ظهرًا – ٨ مساءً"}
            </p>
            <small>جدول توضيحي، لا يعكس مواعيد متاحة للحجز.</small>
          </section>
          <section className="bd-panel">
            <h2>تقييمات العميلات</h2>
            <p>
              لا توجد مراجعات منشورة من عميلات حقيقيات. التقييم المعروض تجريبي.
            </p>
          </section>
        </section>
        <aside className="bd-panel profile-summary">
          <div className="eyebrow">
            <i />
            {salon ? "صالون تجميل" : "خبيرة مستقلة"}
          </div>
          <h1>{p.name}</h1>
          <p>
            <MapPin size={15} />
            {p.city} · {p.area}
          </p>
          <p>
            <Star size={15} className="gold" />
            {p.rating} / 5 · تقييم توضيحي
          </p>
          <div className="bd-line">
            <span>الأسعار تبدأ من</span>
            <b>{p.price} ر.س</b>
          </div>
          <button
            className="primary"
            aria-expanded={booking}
            onClick={() => B(!booking)}
          >
            <CalendarDays size={17} />
            معاينة الحجز
          </button>
          {booking && (
            <div className="booking-preview">
              <label className="bd-field">
                اختاري خدمة للمعاينة
                <select value={option} onChange={(e) => O(+e.target.value)}>
                  {p.offers.map((o, i) => (
                    <option value={i} key={o.title}>
                      {o.title}
                    </option>
                  ))}
                </select>
              </label>
              <p role="status">
                {chosen.price} ر.س · {chosen.minutes} دقيقة
              </p>
              <small>لم يُنشأ حجز. ستتوفر المواعيد عند ربط نظام الحجز.</small>
            </div>
          )}
          <small className="bd-caption">
            ملف تجريبي · لا تتوفر حجوزات فعلية.
          </small>
        </aside>
      </div>
    </>
  );
}
