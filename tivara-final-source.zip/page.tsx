
"use client";

import { useEffect, useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import {
  Upload,
  FileCheck,
  LoaderCircle,
  ShieldCheck,
  Sparkles,
  AlertCircle,
} from "lucide-react";

import { createClient } from "@/lib/supabase-client";
import { Breadcrumb } from "@/components/trail";

type ExpertData = {
  status: string;
};

type SelectedFile = {
  identity: File | null;
  freelance: File | null;
  certificates: File[];
};

const MAX_FILE_SIZE = 10 * 1024 * 1024;

const allowedTypes = [
  "application/pdf",
  "image/jpeg",
  "image/png",
];

export default function ExpertApplicationPage() {
  const router = useRouter();

  const [userId, setUserId] = useState("");
  const [expert, setExpert] = useState<ExpertData | null>(null);
  const [files, setFiles] = useState<SelectedFile>({
    identity: null,
    freelance: null,
    certificates: [],
  });

  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  useEffect(() => {
    let active = true;

    async function loadExpert() {
      const supabase = createClient();

      const {
        data: { user },
        error: authError,
      } = await supabase.auth.getUser();

      if (!active) return;

      if (authError || !user) {
        router.replace("/login?role=expert");
        return;
      }

      setUserId(user.id);

      const { data: profile, error: profileError } = await supabase
        .from("profiles")
        .select("account_type")
        .eq("id", user.id)
        .maybeSingle();

      if (!active) return;

      if (profileError) {
        setError("تعذر التحقق من نوع الحساب.");
        setLoading(false);
        return;
      }

      if (profile?.account_type !== "independent_expert") {
        setError("هذه الصفحة مخصصة للخبيرات المستقلات فقط.");
        setLoading(false);
        return;
      }

      const { data: expertData, error: expertError } = await supabase
        .from("expert_profiles")
        .select("status")
        .eq("owner_id", user.id)
        .maybeSingle();

      if (!active) return;

      if (expertError || !expertData) {
        setError("تعذر العثور على الملف المهني للخبيرة.");
        setLoading(false);
        return;
      }

      setExpert(expertData);
      setLoading(false);
    }

    loadExpert();

    return () => {
      active = false;
    };
  }, [router]);

  function validateFile(file: File) {
    if (!allowedTypes.includes(file.type)) {
      return "يسمح فقط بملفات PDF وJPG وPNG.";
    }

    if (file.size > MAX_FILE_SIZE) {
      return "يجب ألا يتجاوز حجم الملف 10 ميجابايت.";
    }

    return "";
  }

  function selectSingleFile(
    field: "identity" | "freelance",
    file: File | null
  ) {
    setError("");
    setSuccess("");

    if (!file) return;

    const validationError = validateFile(file);

    if (validationError) {
      setError(validationError);
      return;
    }

    setFiles((previous) => ({
      ...previous,
      [field]: file,
    }));
  }

  function selectCertificates(fileList: FileList | null) {
    setError("");
    setSuccess("");

    const selected = Array.from(fileList ?? []);

    if (selected.length === 0) return;

    for (const file of selected) {
      const validationError = validateFile(file);

      if (validationError) {
        setError(`${file.name}: ${validationError}`);
        return;
      }
    }

    setFiles((previous) => ({
      ...previous,
      certificates: selected,
    }));
  }

  async function uploadDocument(
    supabase: ReturnType<typeof createClient>,
    file: File,
    documentType:
      | "national_id"
      | "freelance_certificate"
      | "professional_certificates"
  ) {
    const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");

    const filePath = [
      userId,
      documentType,
      `${crypto.randomUUID()}-${safeName}`,
    ].join("/");

    const { error: uploadError } = await supabase.storage
      .from("expert-documents")
      .upload(filePath, file, {
        upsert: false,
        contentType: file.type,
      });

    if (uploadError) {
      throw new Error(`تعذر رفع الملف ${file.name}. ${uploadError.message}`);
    }

    const { error: insertError } = await supabase
      .from("expert_documents")
      .insert({
        owner_id: userId,
        document_type: documentType,
        file_path: filePath,
        file_name: file.name,
        review_status: "pending",
      });

    if (insertError) {
      throw new Error(
        `تم رفع الملف ${file.name} لكن تعذر تسجيله للمراجعة. ${insertError.message}`
      );
    }
  }

  async function submitApplication(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    setError("");
    setSuccess("");

    if (!files.identity || !files.freelance) {
      setError("يرجى رفع الهوية الوطنية ووثيقة العمل الحر.");
      return;
    }

    if (files.certificates.length === 0) {
      setError("يرجى رفع شهادة أو دورة مهنية واحدة على الأقل.");
      return;
    }

    setUploading(true);

    try {
      const supabase = createClient();

      const {
        data: { user },
        error: authError,
      } = await supabase.auth.getUser();

      if (authError || !user || user.id !== userId) {
        throw new Error("انتهت جلسة الدخول. يرجى تسجيل الدخول مرة أخرى.");
      }

      await uploadDocument(
        supabase,
        files.identity,
        "national_id"
      );

      await uploadDocument(
        supabase,
        files.freelance,
        "freelance_certificate"
      );

      for (const certificate of files.certificates) {
        await uploadDocument(
          supabase,
          certificate,
          "professional_certificates"
        );
      }

      setSuccess(
        "تم رفع وثائقك وتسجيلها بنجاح. طلبك بانتظار مراجعة إدارة تيفارا."
      );

      setFiles({
        identity: null,
        freelance: null,
        certificates: [],
      });
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "حدث خطأ أثناء رفع الوثائق. يرجى المحاولة مرة أخرى."
      );
    } finally {
      setUploading(false);
    }
  }

  if (loading) {
    return (
      <main className="shell" style={{ padding: "80px 0", textAlign: "center" }}>
        <LoaderCircle size={28} />
        <p>جارٍ تحميل ملف الخبيرة...</p>
      </main>
    );
  }

  if (!expert) {
    return (
      <main className="shell" style={{ padding: "60px 0" }}>
        <Breadcrumb current="ملف الخبيرة" />
        <h1>تعذر فتح الملف المهني</h1>
        <p role="alert" style={{ color: "#b42318" }}>
          {error}
        </p>
      </main>
    );
  }

  const statusText =
    expert.status === "approved"
      ? "تم اعتماد ملفك المهني."
      : expert.status === "rejected"
        ? "تم رفض طلب الانضمام. يرجى التواصل مع الإدارة."
        : expert.status === "suspended"
          ? "تم إيقاف الملف مؤقتاً. يرجى التواصل مع الإدارة."
          : "ملفك المهني بانتظار مراجعة إدارة تيفارا.";

  return (
    <main className="shell" style={{ padding: "32px 0 70px" }}>
      <Breadcrumb current="استكمال ملف الخبيرة" />

      <div className="eyebrow">
        <i />
        مجتمع خبيرات تيفارا
      </div>

      <h1 style={{ marginBottom: 8 }}>
        استكمال الملف المهني
      </h1>

      <p style={{ color: "#64748b", marginBottom: 24 }}>
        أكملي بيانات اعتمادك لبدء تقديم خدمات التجميل المنزلية عبر تيفارا.
      </p>

      <section
        className="bd-panel"
        style={{
          maxWidth: 760,
          marginBottom: 24,
          background: "#E6FAF8",
        }}
      >
        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
          <ShieldCheck size={25} color="#0F6B64" />
          <div>
            <strong>حالة الملف المهني</strong>
            <p style={{ margin: "5px 0 0", color: "#0F6B64" }}>
              {statusText}
            </p>
          </div>
        </div>
      </section>

      {expert.status === "approved" ? (
        <section className="bd-panel" style={{ maxWidth: 760 }}>
          <FileCheck size={30} color="#16845d" />
          <h2>ملفك معتمد</h2>
          <p>تم اعتماد ملفك المهني من إدارة تيفارا.</p>
          <button
            className="primary"
            type="button"
            onClick={() => router.push("/account")}
          >
            العودة إلى حسابي
          </button>
        </section>
      ) : expert.status === "suspended" ||
        expert.status === "rejected" ? (
        <section className="bd-panel" style={{ maxWidth: 760 }}>
          <AlertCircle size={28} color="#b42318" />
          <p>{statusText}</p>
        </section>
      ) : (
        <form
          className="bd-panel"
          style={{ maxWidth: 760 }}
          onSubmit={submitApplication}
        >
          <h2>الوثائق المطلوبة</h2>

          <p style={{ color: "#64748b", marginBottom: 24 }}>
            جميع الوثائق التالية إلزامية لإرسال طلب الانضمام.
            الصيغ المقبولة PDF وJPG وPNG، بحد أقصى 10 ميجابايت للملف.
          </p>

          <label className="bd-field">
            <FileCheck size={18} />
            الهوية الوطنية
            <input
              type="file"
              accept=".pdf,.jpg,.jpeg,.png"
              required
              onChange={(event) =>
                selectSingleFile(
                  "identity",
                  event.target.files?.[0] ?? null
                )
              }
            />
            <small>
              {files.identity
                ? `تم الاختيار: ${files.identity.name}`
                : "ارفعي صورة واضحة للهوية الوطنية."}
            </small>
          </label>

          <label className="bd-field" style={{ marginTop: 20 }}>
            <FileCheck size={18} />
            وثيقة العمل الحر
            <input
              type="file"
              accept=".pdf,.jpg,.jpeg,.png"
              required
              onChange={(event) =>
                selectSingleFile(
                  "freelance",
                  event.target.files?.[0] ?? null
                )
              }
            />
            <small>
              {files.freelance
                ? `تم الاختيار: ${files.freelance.name}`
                : "ارفعي وثيقة العمل الحر الخاصة بكِ."}
            </small>
          </label>

          <label className="bd-field" style={{ marginTop: 20 }}>
            <Sparkles size={18} />
            الشهادات والدورات المهنية
            <input
              type="file"
              accept=".pdf,.jpg,.jpeg,.png"
              multiple
              onChange={(event) =>
                selectCertificates(event.target.files)
              }
            />
            <small>
              {files.certificates.length > 0
                ? `تم اختيار ${files.certificates.length} ملف`
                : "يمكنكِ رفع أكثر من شهادة أو دورة مرتبطة بتخصصكِ."}
            </small>
          </label>

          {files.certificates.length > 0 && (
            <ul style={{ marginTop: 10, paddingRight: 24 }}>
              {files.certificates.map((file, index) => (
                <li key={`${file.name}-${index}`}>{file.name}</li>
              ))}
            </ul>
          )}

          {error && (
            <p
              role="alert"
              style={{ color: "#b42318", margin: "18px 0" }}
            >
              {error}
            </p>
          )}

          {success && (
            <p
              role="status"
              style={{ color: "#16845d", margin: "18px 0" }}
            >
              {success}
            </p>
          )}

          <button
            type="submit"
            className="primary"
            disabled={uploading}
            style={{ marginTop: 24 }}
          >
            {uploading ? (
              <LoaderCircle size={18} />
            ) : (
              <Upload size={18} />
            )}
            {uploading
              ? "جارٍ رفع الوثائق..."
              : "إرسال الوثائق للمراجعة"}
          </button>

          <p className="note" style={{ marginTop: 18 }}>
            وثائقك خاصة ولا تظهر للعميلات. تخضع جميع الطلبات لمراجعة
            إدارة تيفارا قبل اعتماد الخبيرة.
          </p>
        </form>
      )}
    </main>
  );
}
