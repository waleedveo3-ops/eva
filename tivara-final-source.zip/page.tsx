
"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Activity,
  ArrowUpRight,
  BadgeCheck,
  Building2,
  CircleAlert,
  FileCheck2,
  LayoutDashboard,
  LogOut,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles,
  Users,
} from "lucide-react";
import { createClient } from "@/lib/supabase-client";

type AdminRole =
  | "super_admin"
  | "operations"
  | "reviewer"
  | "accountant"
  | "support";

type Tab = "overview" | "users" | "experts" | "salons";

type Profile = {
  id: string;
  full_name: string;
  phone: string | null;
  city: string | null;
  account_type: string;
  created_at: string;
};

type Expert = {
  id: string;
  owner_id: string;
  display_name: string;
  city: string | null;
  specialties: string[];
  status: string;
  created_at: string;
};

type Salon = {
  id: string;
  owner_id: string;
  salon_name: string;
  city: string | null;
  commercial_registration: string | null;
  status: string;
  created_at: string;
};

type Doc = {
  id: string;
  owner_id: string;
  document_type: string;
  file_path: string;
  file_name: string | null;
  review_status: string;
  admin_notes: string | null;
  created_at: string;
};

const teal = "#1BA99C";

const statusLabels: Record<string, string> = {
  pending_review: "قيد المراجعة",
  pending: "قيد المراجعة",
  approved: "معتمد",
  rejected: "مرفوض",
  suspended: "موقوف",
  active: "نشط",
  inactive: "غير نشط",
};

const typeLabels: Record<string, string> = {
  customer: "عميل",
  salon: "صالون",
  independent_expert: "خبيرة مستقلة",
};

export default function AdminPage() {
  const router = useRouter();
  const supabase = useMemo(() => createClient(), []);

  const [checking, setChecking] = useState(true);
  const [authorized, setAuthorized] = useState(false);
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<AdminRole | "">("");
  const [tab, setTab] = useState<Tab>("overview");

  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [experts, setExperts] = useState<Expert[]>([]);
  const [salons, setSalons] = useState<Salon[]>([]);
  const [documents, setDocuments] = useState<Doc[]>([]);

  const [loadingData, setLoadingData] = useState(false);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [busyId, setBusyId] = useState("");
  const [notice, setNotice] = useState("");

  const loadData = useCallback(async () => {
    setLoadingData(true);
    setError("");

    const [p, e, s, d] = await Promise.all([
      supabase
        .from("profiles")
        .select("id,full_name,phone,city,account_type,created_at")
        .order("created_at", { ascending: false })
        .limit(500),

      supabase
        .from("expert_profiles")
        .select(
          "id,owner_id,display_name,city,specialties,status,created_at"
        )
        .order("created_at", { ascending: false })
        .limit(500),

      supabase
        .from("salon_profiles")
        .select(
          "id,owner_id,salon_name,city,commercial_registration,status,created_at"
        )
        .order("created_at", { ascending: false })
        .limit(500),

      supabase
        .from("expert_documents")
        .select(
          "id,owner_id,document_type,file_path,file_name,review_status,admin_notes,created_at"
        )
        .order("created_at", { ascending: false })
        .limit(1000),
    ]);

    const firstError = p.error || e.error || s.error || d.error;

    if (firstError) {
      setError(firstError.message);
    }

    setProfiles((p.data ?? []) as Profile[]);
    setExperts((e.data ?? []) as Expert[]);
    setSalons((s.data ?? []) as Salon[]);
    setDocuments((d.data ?? []) as Doc[]);

    setLoadingData(false);
  }, [supabase]);

  useEffect(() => {
    let alive = true;

    async function verifyAdmin() {
      const { data: auth, error: authError } =
        await supabase.auth.getUser();

      if (!alive) return;

      if (authError || !auth.user) {
        router.replace("/login");
        return;
      }

      const { data: admin, error: adminError } = await supabase
        .from("admin_users")
        .select("role,is_active")
        .eq("user_id", auth.user.id)
        .maybeSingle();

      if (!alive) return;

      if (adminError) {
        setError(adminError.message);
        setChecking(false);
        return;
      }

      if (
        !admin ||
        !admin.is_active ||
        !["super_admin", "operations", "reviewer"].includes(admin.role)
      ) {
        setChecking(false);
        setAuthorized(false);
        return;
      }

      setEmail(auth.user.email ?? "");
      setRole(admin.role as AdminRole);
      setAuthorized(true);
      setChecking(false);
    }

    void verifyAdmin();

    return () => {
      alive = false;
    };
  }, [router, supabase]);

  useEffect(() => {
    if (authorized) {
      void loadData();
    }
  }, [authorized, loadData]);

  async function updateStatus(
    table: "expert_profiles" | "salon_profiles",
    id: string,
    nextStatus: string
  ) {
    setBusyId(id);
    setNotice("");
    setError("");

    const { error: updateError } = await supabase
      .from(table)
      .update({ status: nextStatus })
      .eq("id", id);

    if (updateError) {
      setError(updateError.message);
    } else {
      setNotice("تم حفظ التغيير في قاعدة البيانات.");
      await loadData();
    }

    setBusyId("");
  }

  async function reviewDocument(
    doc: Doc,
    nextStatus: "approved" | "rejected"
  ) {
    let notes: string | null = null;

    if (nextStatus === "rejected") {
      notes = window.prompt("اكتب سبب رفض الوثيقة:")?.trim() || null;

      if (!notes) return;
    }

    setBusyId(doc.id);
    setNotice("");
    setError("");

    const { error: docError } = await supabase
      .from("expert_documents")
      .update({
        review_status: nextStatus,
        admin_notes: notes,
        reviewed_at: new Date().toISOString(),
      })
      .eq("id", doc.id);

    if (docError) {
      setError(docError.message);
    } else {
      setNotice("تم تحديث حالة الوثيقة.");
      await loadData();
    }

    setBusyId("");
  }

  async function openDocument(doc: Doc) {
    const { data, error: signedError } = await supabase.storage
      .from("expert-documents")
      .createSignedUrl(doc.file_path, 60);

    if (signedError || !data?.signedUrl) {
      setError(
        signedError?.message ?? "تعذر إنشاء رابط آمن للوثيقة."
      );
      return;
    }

    window.open(data.signedUrl, "_blank", "noopener,noreferrer");
  }

  async function logout() {
    await supabase.auth.signOut();
    router.replace("/login");
    router.refresh();
  }

  const filteredProfiles = profiles.filter((x) =>
    `${x.full_name} ${x.phone ?? ""} ${x.city ?? ""} ${x.account_type}`
      .toLowerCase()
      .includes(query.toLowerCase())
  );

  const filteredExperts = experts.filter((x) =>
    `${x.display_name} ${x.city ?? ""} ${x.status}`
      .toLowerCase()
      .includes(query.toLowerCase())
  );

  const filteredSalons = salons.filter((x) =>
    `${x.salon_name} ${x.city ?? ""} ${x.status}`
      .toLowerCase()
      .includes(query.toLowerCase())
  );

  const pendingExperts = experts.filter(
    (x) => x.status === "pending_review"
  ).length;

  const pendingSalons = salons.filter(
    (x) => x.status === "pending_review"
  ).length;

  const pendingDocs = documents.filter(
    (x) => x.review_status === "pending"
  ).length;

  const nav: {
    id: Tab;
    label: string;
    icon: React.ReactNode;
  }[] = [
    {
      id: "overview",
      label: "نظرة عامة",
      icon: <LayoutDashboard size={18} />,
    },
    {
      id: "users",
      label: "المستخدمون",
      icon: <Users size={18} />,
    },
    {
      id: "experts",
      label: "الخبيرات المستقلات",
      icon: <Sparkles size={18} />,
    },
    {
      id: "salons",
      label: "الصالونات",
      icon: <Building2 size={18} />,
    },
  ];

  if (checking) {
    return (
      <main style={styles.center}>
        جارٍ التحقق من صلاحيات الإدارة...
      </main>
    );
  }

  if (!authorized) {
    return (
      <main style={styles.center}>
        <section style={styles.panel}>
          <ShieldCheck size={42} color={teal} />
          <h1>غير مصرح بالدخول</h1>
          <p>
            هذه الصفحة مخصصة للمستخدمين المخولين في إدارة تيفارا.
          </p>
          <button
            style={styles.primary}
            onClick={() => router.push("/")}
          >
            العودة للموقع
          </button>
        </section>
      </main>
    );
  }

  return (
    <main dir="rtl" style={styles.page}>
      <header style={styles.header}>
        <div>
          <div style={styles.brand}>
            TIVARA <span>تيفارا</span>
          </div>
          <div style={styles.muted}>مركز إدارة المنصة</div>
        </div>

        <div style={styles.headerRight}>
          <span style={styles.role}>
            <ShieldCheck size={15} />
            {role === "super_admin" ? "مدير رئيسي" : "إدارة"}
          </span>

          <span style={styles.email}>{email}</span>

          <button style={styles.outline} onClick={logout}>
            <LogOut size={16} />
            خروج
          </button>
        </div>
      </header>

      <div style={styles.shell}>
        <aside style={styles.sidebar}>
          <div style={styles.sideTitle}>القائمة الرئيسية</div>

          {nav.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setTab(item.id);
                setQuery("");
              }}
              style={{
                ...styles.navItem,
                ...(tab === item.id ? styles.navActive : {}),
              }}
            >
              {item.icon}
              {item.label}
            </button>
          ))}

          <div style={styles.sideNote}>
            الصلاحيات تطبق من قاعدة البيانات، وليس من إظهار عناصر
            الواجهة فقط.
          </div>
        </aside>

        <section style={styles.content}>
          <div style={styles.pageHead}>
            <div>
              <div style={styles.eyebrow}>
                TIVARA ADMINISTRATION
              </div>

              <h1 style={styles.heading}>
                {nav.find((x) => x.id === tab)?.label}
              </h1>

              <p style={styles.muted}>
                إدارة بيانات المنصة ومراجعة طلبات مقدمي الخدمات.
              </p>
            </div>

            <button
              style={styles.outline}
              onClick={() => void loadData()}
              disabled={loadingData}
            >
              <RefreshCw size={16} />
              تحديث البيانات
            </button>
          </div>

          {error && (
            <div style={styles.error}>
              <CircleAlert size={18} />
              {error}
            </div>
          )}

          {notice && (
            <div style={styles.success}>
              <BadgeCheck size={18} />
              {notice}
            </div>
          )}

          {tab === "overview" && (
            <>
              <div style={styles.stats}>
                <Stat
                  icon={<Users />}
                  title="إجمالي المستخدمين"
                  value={profiles.length}
                />
                <Stat
                  icon={<Sparkles />}
                  title="الخبيرات"
                  value={experts.length}
                />
                <Stat
                  icon={<Building2 />}
                  title="الصالونات"
                  value={salons.length}
                />
                <Stat
                  icon={<FileCheck2 />}
                  title="وثائق قيد المراجعة"
                  value={pendingDocs}
                />
              </div>

              <div style={styles.statsSmall}>
                <div style={styles.statSmall}>
                  <span>طلبات خبيرات معلقة</span>
                  <b>{pendingExperts}</b>
                </div>

                <div style={styles.statSmall}>
                  <span>طلبات صالونات معلقة</span>
                  <b>{pendingSalons}</b>
                </div>

                <div style={styles.statSmall}>
                  <span>آخر تحديث</span>
                  <b>
                    {new Date().toLocaleTimeString("ar-SA", {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </b>
                </div>
              </div>

              <div style={styles.panel}>
                <h2 style={styles.subheading}>إجراءات سريعة</h2>

                <div style={styles.quick}>
                  <button
                    style={styles.quickButton}
                    onClick={() => setTab("experts")}
                  >
                    <Sparkles />
                    مراجعة الخبيرات
                    <ArrowUpRight />
                  </button>

                  <button
                    style={styles.quickButton}
                    onClick={() => setTab("salons")}
                  >
                    <Building2 />
                    مراجعة الصالونات
                    <ArrowUpRight />
                  </button>

                  <button
                    style={styles.quickButton}
                    onClick={() => setTab("users")}
                  >
                    <Users />
                    عرض المستخدمين
                    <ArrowUpRight />
                  </button>
                </div>
              </div>

              <div style={styles.info}>
                <Activity size={18} />
                الأقسام المالية والحجوزات والخدمات ستظهر بعد إنشاء
                جداولها وربط مزود الدفع. لا توجد بيانات مالية تجريبية
                معروضة هنا.
              </div>
            </>
          )}

          {tab !== "overview" && (
            <>
              <div style={styles.search}>
                <Search size={18} />
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="ابحث بالاسم أو المدينة أو الحالة..."
                />
              </div>

              {loadingData ? (
                <div style={styles.panel}>
                  جارٍ تحميل البيانات...
                </div>
              ) : tab === "users" ? (
                <div style={styles.panel}>
                  <h2 style={styles.subheading}>
                    حسابات المستخدمين ({filteredProfiles.length})
                  </h2>

                  <div style={styles.tableWrap}>
                    <table style={styles.table}>
                      <thead>
                        <tr>
                          <th>الاسم</th>
                          <th>نوع الحساب</th>
                          <th>رقم الجوال</th>
                          <th>المدينة</th>
                          <th>تاريخ التسجيل</th>
                        </tr>
                      </thead>

                      <tbody>
                        {filteredProfiles.map((p) => (
                          <tr key={p.id}>
                            <td>{p.full_name}</td>
                            <td>
                              {typeLabels[p.account_type] ??
                                p.account_type}
                            </td>
                            <td dir="ltr">{p.phone ?? "—"}</td>
                            <td>{p.city ?? "—"}</td>
                            <td>
                              {new Date(p.created_at).toLocaleDateString(
                                "ar-SA"
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>

                    {filteredProfiles.length === 0 && (
                      <p style={styles.empty}>لا توجد نتائج.</p>
                    )}
                  </div>
                </div>
              ) : tab === "experts" ? (
                <>
                  <div style={styles.panel}>
                    <h2 style={styles.subheading}>
                      طلبات الخبيرات ({filteredExperts.length})
                    </h2>

                    <div style={styles.tableWrap}>
                      <table style={styles.table}>
                        <thead>
                          <tr>
                            <th>الخبيرة</th>
                            <th>المدينة</th>
                            <th>التخصصات</th>
                            <th>الحالة</th>
                            <th>الإجراء</th>
                          </tr>
                        </thead>

                        <tbody>
                          {filteredExperts.map((x) => (
                            <tr key={x.id}>
                              <td>{x.display_name}</td>
                              <td>{x.city ?? "—"}</td>
                              <td>
                                {x.specialties?.join("، ") || "—"}
                              </td>
                              <td>
                                <Status value={x.status} />
                              </td>
                              <td>
                                <div style={styles.actions}>
                                  <button
                                    disabled={busyId === x.id}
                                    style={styles.smallGreen}
                                    onClick={() =>
                                      void updateStatus(
                                        "expert_profiles",
                                        x.id,
                                        "approved"
                                      )
                                    }
                                  >
                                    اعتماد
                                  </button>

                                  <button
                                    disabled={busyId === x.id}
                                    style={styles.smallRed}
                                    onClick={() =>
                                      void updateStatus(
                                        "expert_profiles",
                                        x.id,
                                        "rejected"
                                      )
                                    }
                                  >
                                    رفض
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>

                      {filteredExperts.length === 0 && (
                        <p style={styles.empty}>لا توجد خبيرات.</p>
                      )}
                    </div>
                  </div>

                  <div style={styles.panel}>
                    <h2 style={styles.subheading}>
                      وثائق الخبيرات ({documents.length})
                    </h2>

                    <div style={styles.tableWrap}>
                      <table style={styles.table}>
                        <thead>
                          <tr>
                            <th>اسم الملف</th>
                            <th>نوع الوثيقة</th>
                            <th>الحالة</th>
                            <th>التاريخ</th>
                            <th>الإجراءات</th>
                          </tr>
                        </thead>

                        <tbody>
                          {documents.map((d) => (
                            <tr key={d.id}>
                              <td>
                                {d.file_name ??
                                  d.file_path.split("/").pop()}
                              </td>

                              <td>
                                {(
                                  {
                                    national_id: "الهوية الوطنية",
                                    freelance_certificate:
                                      "وثيقة العمل الحر",
                                    professional_certificates:
                                      "الشهادات المهنية",
                                  } as Record<string, string>
                                )[d.document_type] ?? d.document_type}
                              </td>

                              <td>
                                <Status value={d.review_status} />
                              </td>

                              <td>
                                {new Date(d.created_at).toLocaleDateString(
                                  "ar-SA"
                                )}
                              </td>

                              <td>
                                <div style={styles.actions}>
                                  <button
                                    style={styles.outlineSmall}
                                    onClick={() => void openDocument(d)}
                                  >
                                    فتح الوثيقة
                                  </button>

                                  <button
                                    disabled={busyId === d.id}
                                    style={styles.smallGreen}
                                    onClick={() =>
                                      void reviewDocument(d, "approved")
                                    }
                                  >
                                    قبول
                                  </button>

                                  <button
                                    disabled={busyId === d.id}
                                    style={styles.smallRed}
                                    onClick={() =>
                                      void reviewDocument(d, "rejected")
                                    }
                                  >
                                    رفض
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>

                      {documents.length === 0 && (
                        <p style={styles.empty}>
                          لا توجد وثائق مرفوعة.
                        </p>
                      )}
                    </div>
                  </div>
                </>
              ) : (
                <div style={styles.panel}>
                  <h2 style={styles.subheading}>
                    الصالونات ({filteredSalons.length})
                  </h2>

                  <div style={styles.tableWrap}>
                    <table style={styles.table}>
                      <thead>
                        <tr>
                          <th>اسم الصالون</th>
                          <th>المدينة</th>
                          <th>السجل التجاري</th>
                          <th>الحالة</th>
                          <th>الإجراء</th>
                        </tr>
                      </thead>

                      <tbody>
                        {filteredSalons.map((x) => (
                          <tr key={x.id}>
                            <td>{x.salon_name}</td>
                            <td>{x.city ?? "—"}</td>
                            <td>{x.commercial_registration ?? "—"}</td>
                            <td>
                              <Status value={x.status} />
                            </td>
                            <td>
                              <div style={styles.actions}>
                                <button
                                  disabled={busyId === x.id}
                                  style={styles.smallGreen}
                                  onClick={() =>
                                    void updateStatus(
                                      "salon_profiles",
                                      x.id,
                                      "approved"
                                    )
                                  }
                                >
                                  اعتماد
                                </button>

                                <button
                                  disabled={busyId === x.id}
                                  style={styles.smallRed}
                                  onClick={() =>
                                    void updateStatus(
                                      "salon_profiles",
                                      x.id,
                                      "rejected"
                                    )
                                  }
                                >
                                  رفض
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>

                    {filteredSalons.length === 0 && (
                      <p style={styles.empty}>لا توجد صالونات.</p>
                    )}
                  </div>
                </div>
              )}
            </>
          )}
        </section>
      </div>
    </main>
  );
}

function Stat({
  icon,
  title,
  value,
}: {
  icon: React.ReactNode;
  title: string;
  value: number;
}) {
  return (
    <div style={styles.stat}>
      <div style={styles.statIcon}>{icon}</div>
      <div>
        <div style={styles.statTitle}>{title}</div>
        <div style={styles.statValue}>
          {value.toLocaleString("ar-SA")}
        </div>
      </div>
    </div>
  );
}

function Status({ value }: { value: string }) {
  const good = value === "approved";
  const bad = value === "rejected" || value === "suspended";

  return (
    <span
      style={{
        ...styles.status,
        background: good
          ? "#E2F6EE"
          : bad
            ? "#FCE8E8"
            : "#FFF4D9",
        color: good
          ? "#18794E"
          : bad
            ? "#B42318"
            : "#946200",
      }}
    >
      {statusLabels[value] ?? value}
    </span>
  );
}

const styles: Record<string, React.CSSProperties> = {
  page: {
    minHeight: "100vh",
    background: "#E6FAF8",
    color: "#173B38",
    fontFamily: "Cairo, Arial, sans-serif",
  },

  center: {
    minHeight: "100vh",
    display: "grid",
    placeItems: "center",
    padding: 24,
    color: "#0F6B64",
    textAlign: "center",
  },

  header: {
    minHeight: 76,
    background: "#fff",
    borderBottom: "1px solid #D5EFEB",
    padding: "12px 3%",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 16,
    flexWrap: "wrap",
  },

  brand: {
    fontSize: 23,
    fontWeight: 800,
    color: "#0F6B64",
    letterSpacing: 1,
  },

  muted: {
    color: "#78938F",
    fontSize: 13,
    marginTop: 4,
  },

  headerRight: {
    display: "flex",
    alignItems: "center",
    gap: 14,
    flexWrap: "wrap",
  },

  role: {
    display: "inline-flex",
    alignItems: "center",
    gap: 6,
    color: "#0F6B64",
    background: "#E6FAF8",
    padding: "7px 10px",
    borderRadius: 20,
    fontSize: 12,
  },

  email: {
    color: "#78938F",
    fontSize: 12,
    direction: "ltr",
  },

  shell: {
    display: "grid",
    gridTemplateColumns: "245px minmax(0,1fr)",
    minHeight: "calc(100vh - 76px)",
  },

  sidebar: {
    background: "#fff",
    borderLeft: "1px solid #D5EFEB",
    padding: 18,
  },

  sideTitle: {
    color: "#78938F",
    fontSize: 12,
    margin: "8px 10px 18px",
  },

  navItem: {
    width: "100%",
    border: 0,
    background: "transparent",
    display: "flex",
    alignItems: "center",
    gap: 10,
    padding: "12px 13px",
    borderRadius: 9,
    color: "#45635F",
    fontFamily: "inherit",
    fontSize: 13,
    fontWeight: 400,
    textAlign: "right",
    cursor: "pointer",
    marginBottom: 5,
  },

  navActive: {
    background: "#E6FAF8",
    color: "#0F6B64",
    fontWeight: 700,
  },

  sideNote: {
    marginTop: 24,
    background: "#F0FBF9",
    color: "#567A75",
    padding: 12,
    borderRadius: 9,
    fontSize: 11,
    lineHeight: 1.8,
  },

  content: {
    padding: "28px 3%",
    minWidth: 0,
  },

  pageHead: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 15,
    flexWrap: "wrap",
    marginBottom: 22,
  },

  eyebrow: {
    color: teal,
    fontSize: 11,
    fontWeight: 800,
    letterSpacing: 1,
  },

  heading: {
    color: "#0F6B64",
    fontSize: 26,
    margin: "6px 0",
  },

  outline: {
    display: "inline-flex",
    alignItems: "center",
    gap: 8,
    background: "#fff",
    color: "#0F6B64",
    border: "1px solid #CDE9E4",
    borderRadius: 9,
    padding: "10px 13px",
    cursor: "pointer",
    fontFamily: "inherit",
    fontSize: 12,
  },

  primary: {
    background: teal,
    color: "#fff",
    border: 0,
    borderRadius: 9,
    padding: "11px 18px",
    cursor: "pointer",
    fontFamily: "inherit",
  },

  stats: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit,minmax(190px,1fr))",
    gap: 14,
  },

  stat: {
    background: "#fff",
    border: "1px solid #D5EFEB",
    borderRadius: 13,
    padding: 18,
    display: "flex",
    alignItems: "center",
    gap: 13,
  },

  statIcon: {
    width: 43,
    height: 43,
    borderRadius: 12,
    background: "#E6FAF8",
    color: teal,
    display: "grid",
    placeItems: "center",
  },

  statTitle: {
    color: "#78938F",
    fontSize: 12,
  },

  statValue: {
    color: "#0F6B64",
    fontSize: 25,
    fontWeight: 800,
    marginTop: 3,
  },

  statsSmall: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit,minmax(170px,1fr))",
    gap: 12,
    marginTop: 14,
  },

  statSmall: {
    background: "#fff",
    border: "1px solid #D5EFEB",
    borderRadius: 11,
    padding: 15,
    display: "flex",
    justifyContent: "space-between",
    gap: 10,
    fontSize: 12,
    color: "#78938F",
  },

  panel: {
    background: "#fff",
    border: "1px solid #D5EFEB",
    borderRadius: 13,
    padding: 18,
    marginTop: 16,
    minWidth: 0,
  },

  subheading: {
    color: "#0F6B64",
    fontSize: 16,
    margin: "0 0 14px",
  },

  quick: {
    display: "flex",
    flexWrap: "wrap",
    gap: 10,
  },

  quickButton: {
    display: "inline-flex",
    alignItems: "center",
    gap: 9,
    border: "1px solid #D5EFEB",
    background: "#F8FEFD",
    color: "#0F6B64",
    borderRadius: 9,
    padding: "12px 14px",
    cursor: "pointer",
    fontFamily: "inherit",
    fontSize: 12,
  },

  info: {
    display: "flex",
    alignItems: "center",
    gap: 9,
    marginTop: 16,
    background: "#F0FBF9",
    color: "#567A75",
    padding: 14,
    borderRadius: 10,
    fontSize: 12,
  },

  search: {
    display: "flex",
    alignItems: "center",
    gap: 10,
    background: "#fff",
    border: "1px solid #D5EFEB",
    borderRadius: 10,
    padding: "0 13px",
    marginBottom: 14,
    color: "#78938F",
  },

  tableWrap: {
    width: "100%",
    overflowX: "auto",
  },

  table: {
    width: "100%",
    borderCollapse: "collapse",
    textAlign: "right",
    fontSize: 12,
    minWidth: 680,
  },

  empty: {
    color: "#78938F",
    textAlign: "center",
    padding: 20,
  },

  status: {
    display: "inline-block",
    borderRadius: 20,
    padding: "5px 9px",
    fontSize: 11,
    whiteSpace: "nowrap",
  },

  actions: {
    display: "flex",
    alignItems: "center",
    gap: 6,
    flexWrap: "wrap",
  },

  smallGreen: {
    border: 0,
    background: "#E2F6EE",
    color: "#18794E",
    borderRadius: 7,
    padding: "7px 9px",
    cursor: "pointer",
    fontFamily: "inherit",
    fontSize: 11,
  },

  smallRed: {
    border: 0,
    background: "#FCE8E8",
    color: "#B42318",
    borderRadius: 7,
    padding: "7px 9px",
    cursor: "pointer",
    fontFamily: "inherit",
    fontSize: 11,
  },

  outlineSmall: {
    border: "1px solid #CDE9E4",
    background: "#fff",
    color: "#0F6B64",
    borderRadius: 7,
    padding: "7px 9px",
    cursor: "pointer",
    fontFamily: "inherit",
    fontSize: 11,
  },

  error: {
    display: "flex",
    gap: 8,
    alignItems: "center",
    color: "#B42318",
    background: "#FCE8E8",
    padding: 12,
    borderRadius: 9,
    marginBottom: 12,
    fontSize: 12,
  },

  success: {
    display: "flex",
    gap: 8,
    alignItems: "center",
    color: "#18794E",
    background: "#E2F6EE",
    padding: 12,
    borderRadius: 9,
    marginBottom: 12,
    fontSize: 12,
  },
};
