import Link from "next/link";
import { ArrowLeft, Store, Sparkles } from "lucide-react";
import { Breadcrumb } from "@/components/trail";
export const metadata = { title: "شركاء الجمال | تيفارا" };
export default function Partner() {
  return (
    <>
      <Breadcrumb current="شركاء الجمال" />
      <section className="bd-banner partner-banner">
        <div>
          <div className="eyebrow">
            <i />
            شركاء تيفارا
          </div>
          <h1>لمستكِ تستحق أن تُكتشف</h1>
          <p>
            عرّفي العميلات بخدماتكِ في الرياض وجدة. اختاري مسار الشراكة الذي يناسب
            طبيعة عملكِ.
          </p>
        </div>
        <img src="/salons1.webp" alt="مساحة تصفيف الشعر" />
      </section>
      <section className="section">
        <div className="eyebrow">
          <i />
          مسارات الشراكة
        </div>
        <h2>كيف تقدمين خدماتكِ؟</h2>
        <div className="partner-paths">
          {[
            {
              role: "salon",
              name: "صالون تجميل",
              text: "اجمعي تفاصيل فروعكِ وساعات العمل وقائمة الخدمات والأسعار في ملف واحد.",
              Icon: Store,
            },
            {
              role: "expert",
              name: "خبيرة مستقلة",
              text: "اعرضي تخصصاتكِ وصور أعمالكِ وحددي المدينة والأوقات التي تناسبكِ.",
              Icon: Sparkles,
            },
          ].map(({ role, name, text, Icon }) => (
            <article key={role} className="bd-panel">
              <span className="iconwell">
                <Icon />
              </span>
              <h2>{name}</h2>
              <p>{text}</p>
              <Link className="textlink" href={"/register?role=" + role}>
                استكشفي مسار التسجيل
                <ArrowLeft size={15} />
              </Link>
            </article>
          ))}
        </div>
      </section>
      <section className="section how">
        <h2>خطوات الانضمام عند الإطلاق</h2>
        <div className="threegrid">
          {[
            [
              "١",
              "اختاري نوع الحساب",
              "صالون بفروع أو خبيرة تقدم خدماتها باستقلالية.",
            ],
            ["٢", "جهزي ملفكِ", "أضيفي وصفًا وصورًا وخدمات وأسعارًا وأوقات العمل."],
            [
              "٣",
              "أرسلي طلبكِ للمراجعة",
              "بعد إتاحة التسجيل، يراجع الفريق التفاصيل قبل نشر الملف.",
            ],
          ].map(([n, t, d]) => (
            <div className="step" key={n}>
              <span>{n}</span>
              <h3>{t}</h3>
              <p>{d}</p>
            </div>
          ))}
        </div>
      </section>
      <p className="bd-caption">
        معاينة لمسار الشراكة. لا يتم استقبال طلبات أو نشر ملفات حاليًا.
      </p>
    </>
  );
}
