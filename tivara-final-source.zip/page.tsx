import { AccountPreview } from "@/components/account-preview";

export const metadata = {
  title: "إنشاء حساب | تيفارا",
};

export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ role?: string }>;
}) {
  return (
    <AccountPreview
      register={true}
      role={(await searchParams).role}
    />
  );
}