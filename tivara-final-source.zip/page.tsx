
"use client";

import { useEffect, useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import {
  UserRound,
  Mail,
  Phone,
  MapPin,
  Save,
  LoaderCircle,
  CalendarDays,
  Heart,
  Settings,
} from "lucide-react";

import { createClient } from "@/lib/supabase-client";
import { Breadcrumb } from "@/components/trail";

type ProfileData = {
  full_name: string;
  phone: string | null;
  city: string | null;
  account_type: string;
};

export default function AccountPage() {
  const router = useRouter();

  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [city, setCity] = useState("");
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [messageType, setMessageType] = useState<"error" | "success">("error");

  useEffect(() => {
    const supabase = createClient();
    let active = true;

    async function loadProfile() {
      try {
        const {
          data: { user },
          error: authError,
        } = await supabase.auth.getUser();

        if (!active) return;

        if (authError) {
          setMessage("تعذر التحقق من جلسة الدخول: " + authError.message);
          setLoading(false);
          return;
        }

        if (!user) {
          router.replace("/login");
          return;
        }

        setEmail(user.email ?? "");

        const { data, error } = await supabase
          .from("profiles")
          .select("full_name, phone, city, account_type")
          .eq("id", user.id)
          .maybeSingle();

        if (!active) return;

        if (error) {
          console.error("Profile loading error:", error);

          setMessage(
            `خطأ قاعدة البيانات: ${error.message} (Code: ${error.code})`
          );
          setLoading(false);
          return;
        }

        if (!data) {
          setMessage(
            "لم يتم العثور على سجل لهذا الحساب في جدول profiles. يرجى التحقق من إنشاء سجل المستخدم."
          );
          setLoading(false);
          return;
        }

        setProfile(data);
        setName(data.full_name ?? "");
        setPhone(data.phone ?? "");
        setCity(data.city ?? "");
        setLoading(false);
      } catch (error) {
        console.error("Account loading error:", error);

        if (active) {
          setMessage(
            error instanceof Error
              ? error.message
              : "حدث خطأ غير متوقع أثناء تحميل الحساب."
          );
          setLoading(false);
        }
      }
    }

    loadProfile();

    return () => {
      active = false;
    };
  }, [router]);

  async function saveProfile(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();

    setSaving(true);
    setMessage("");

    try {
      const supabase = createClient();

      const {
        data: { user },
        error: authError,
      } = await supabase.auth.getUser();

      if (authError || !user) {
        setMessage("انتهت جلسة الدخول. يرجى تسجيل الدخول مرة أخرى.");
        setMessageType("error");
        setSaving(false);
        return;
      }

      const { error } = await supabase
        .from("profiles")
        .update({
          full_name: name.trim(),
          phone: phone.trim() || null,
          city: city.trim() || null,
          updated_at: new Date().toISOString(),
        })
        .eq("id", user.id);

      if (error) {
        console.error("Profile update error:", error);

        setMessage(
          `تعذر حفظ البيانات: ${error.message} (Code: ${error.code})`
        );
        setMessageType("error");
        setSaving(false);
        return;
      }

      const updatedProfile: ProfileData = {
        ...profile!,
        full_name: name.trim(),
        phone: phone.trim() || null,
        city: city.trim() || null,
      };

      setProfile(updatedProfile);
      setMessage("تم حفظ بياناتك بنجاح.");
      setMessageType("success");
      setSaving(false);
      router.refresh();
    } catch (error) {
      console.error("Profile update error:", error);

      setMessage(
        error instanceof Error
          ? error.message
          : "حدث خطأ غير متوقع أثناء حفظ البيانات."
      );
      setMessageType("error");
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <main className="shell" style={{ padding: "80px 0", textAlign: "center" }}>
        <LoaderCircle size={28} />
        <p>جارٍ تحميل بيانات حسابك...</p>
      </main>
    );
  }

  if (!profile) {
    return (
      <main className="shell" style={{ padding: "60px 0" }}>
        <Breadcrumb current="حسابي" />
        <h1>تعذر تحميل الحساب</h1>
        <div
          role="alert"
          style={{
            marginTop: 20,
            padding: 16,
            border: "1px solid #e5b4b4",
            borderRadius: 12,
            color: "#a12b2b",
            direction: "rtl",
          }}
        >
          {message}
        </div>
        <button
          className="primary"
          style={{ marginTop: 20 }}
          onClick={() => window.location.reload()}
        >
          إعادة المحاولة
        </button>
      </main>
    );
  }

  const accountType =
    profile.account_type === "customer"
      ? "عميلة"
      : profile.account_type === "salon"
        ? "صالون"
        : "خبيرة مستقلة";

  return (
    <main className="shell" style={{ padding: "32px 0 70px" }}>
      <Breadcrumb current="حسابي" />

      <div className="eyebrow">
        <i />
        حساب تيفارا
      </div>

      <h1 style={{ marginBottom: 8 }}>مرحباً، {profile.full_name}</h1>

      <p style={{ color: "#64748b", marginBottom: 28 }}>
        يمكنك الاطلاع على بيانات حسابك وتحديثها من هنا.
      </p>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
          gap: 16,
          marginBottom: 28,
        }}
      >
        {[
          {
            icon: CalendarDays,
            title: "حجوزاتي",
            desc: "ستظهر حجوزاتك هنا.",
          },
          {
            icon: Heart,
            title: "المفضلة",
            desc: "احتفظي بخدماتك المفضلة.",
          },
          {
            icon: Settings,
            title: "إعدادات الحساب",
            desc: "إدارة حسابك.",
          },
        ].map((item) => (
          <section
            key={item.title}
            className="bd-panel"
            style={{ padding: 20 }}
          >
            <item.icon size={23} color="#1BA99C" />
            <h3>{item.title}</h3>
            <small>{item.desc}</small>
          </section>
        ))}
      </div>

      <section className="bd-panel" style={{ maxWidth: 720 }}>
        <div className="eyebrow">
          <i />
          معلومات الحساب
        </div>

        <h2>البيانات الشخصية</h2>

        <p style={{ marginBottom: 20 }}>
          نوع الحساب: <strong>{accountType}</strong>
        </p>

        <form onSubmit={saveProfile}>
          <label className="bd-field">
            <UserRound size={16} />
            الاسم الكامل
            <input
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="الاسم الكامل"
            />
          </label>

          <label className="bd-field">
            <Mail size={16} />
            البريد الإلكتروني
            <input value={email} disabled dir="ltr" />
          </label>

          <label className="bd-field">
            <Phone size={16} />
            رقم الجوال
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="05xxxxxxxx"
              dir="ltr"
            />
          </label>

          <label className="bd-field">
            <MapPin size={16} />
            المدينة
            <select
              value={city}
              onChange={(e) => setCity(e.target.value)}
            >
              <option value="">اختاري المدينة</option>
              <option value="الرياض">الرياض</option>
              <option value="جدة">جدة</option>
              <option value="مكة المكرمة">مكة المكرمة</option>
              <option value="المدينة المنورة">المدينة المنورة</option>
              <option value="الدمام">الدمام</option>
              <option value="الخبر">الخبر</option>
              <option value="الطائف">الطائف</option>
              <option value="أخرى">أخرى</option>
            </select>
          </label>

          {message && (
            <p
              role="status"
              style={{
                margin: "16px 0",
                color: messageType === "success" ? "#16845d" : "#b42318",
              }}
            >
              {message}
            </p>
          )}

          <button className="primary" type="submit" disabled={saving}>
            {saving ? (
              <LoaderCircle size={17} />
            ) : (
              <Save size={17} />
            )}
            {saving ? "جارٍ الحفظ..." : "حفظ التعديلات"}
          </button>
        </form>
      </section>
    </main>
  );
}
