import { AccountPreview } from "@/components/account-preview";

export const metadata = {
  title: "تسجيل الدخول | تيفارا",
};

export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ role?: string }>;
}) {
  return (
    <AccountPreview
      register={false}
      role={(await searchParams).role}
    />
  );
}