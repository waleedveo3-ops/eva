
"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  LockKeyhole,
  Store,
  UserRound,
  Sparkles,
} from "lucide-react";
import { Breadcrumb } from "./trail";
import { createClient } from "@/lib/supabase-client";

const roles = {
  customer: {
    title: "عميلة",
    icon: UserRound,
    description: "اكتشفي الصالونات والخبيرات واحتفظي بخدماتكِ المفضلة.",
  },
  salon: {
    title: "صالون",
    icon: Store,
    description: "قدّمي صالونكِ وفروعكِ وخدماتكِ للعميلات في مدينتكِ.",
  },
  expert: {
    title: "خبيرة مستقلة",
    icon: Sparkles,
    description: "عرّفي العميلات بتخصصكِ وأعمالكِ ونطاق تقديم خدماتكِ.",
  },
};

type Role = keyof typeof roles;

export function AccountPreview({
  register,
  role,
}: {
  register: boolean;
  role?: string;
}) {
  const router = useRouter();

  const r: Role =
    role === "expert" || role === "salon" ? role : "customer";

  const base = register ? "/register" : "/login";
  const title = register ? "إنشاء حساب" : "تسجيل الدخول";

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  async function handleRegister(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    setError("");
    setSuccess("");

    const form = new FormData(event.currentTarget);

    const fullName = String(form.get("full_name") || "").trim();
    const email = String(form.get("email") || "").trim();
    const password = String(form.get("password") || "");
    const phone = String(form.get("phone") || "").trim();
    const city = String(form.get("city") || "").trim();

    const salonName = String(form.get("salon_name") || "").trim();

    const commercialRegistration = String(
      form.get("commercial_registration") || ""
    ).trim();

    const specialtiesText = String(form.get("specialties") || "");

    const specialties = specialtiesText
      .split(/[,،]/)
      .map((item) => item.trim())
      .filter(Boolean);

    if (!fullName || !email || !password || !city) {
      setError("يرجى تعبئة جميع الحقول المطلوبة.");
      return;
    }

    if (password.length < 8) {
      setError("يجب أن تتكون كلمة المرور من 8 أحرف أو أرقام على الأقل.");
      return;
    }

    if (r === "salon" && !salonName) {
      setError("يرجى إدخال اسم الصالون.");
      return;
    }

    if (r === "expert" && specialties.length === 0) {
      setError("يرجى إدخال تخصص واحد على الأقل.");
      return;
    }

    setLoading(true);

    try {
      const supabase = createClient();

      const accountType =
        r === "expert" ? "independent_expert" : r;

      const { data, error: signUpError } =
        await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/login?role=${r}`,
            data: {
              full_name: fullName,
              phone: phone || null,
              city,
              account_type: accountType,
              ...(r === "salon"
                ? {
                    salon_name: salonName,
                    commercial_registration:
                      commercialRegistration || null,
                  }
                : {}),
              ...(r === "expert"
                ? {
                    specialties,
                  }
                : {}),
            },
          },
        });

      if (signUpError) {
        setError(
          signUpError.message === "User already registered"
            ? "هذا البريد الإلكتروني مسجل مسبقاً."
            : "تعذر إنشاء الحساب. يرجى مراجعة البيانات والمحاولة مرة أخرى."
        );
        return;
      }

      if (data.session) {
        setSuccess("تم إنشاء حسابك بنجاح.");
        router.refresh();
      } else {
        setSuccess(
          "تم إنشاء حسابك بنجاح. يرجى التحقق من بريدك الإلكتروني لتفعيل الحساب."
        );
      }
    } catch {
      setError("حدث خطأ أثناء إنشاء الحساب. يرجى المحاولة مرة أخرى.");
    } finally {
      setLoading(false);
    }
  }

  async function handleLogin(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    setError("");
    setSuccess("");

    const form = new FormData(event.currentTarget);

    const email = String(form.get("email") || "").trim();
    const password = String(form.get("password") || "");

    if (!email || !password) {
      setError("يرجى إدخال البريد الإلكتروني وكلمة المرور.");
      return;
    }

    setLoading(true);

    try {
      const supabase = createClient();

      const { error: loginError } =
        await supabase.auth.signInWithPassword({
          email,
          password,
        });

      if (loginError) {
        if (loginError.message === "Invalid login credentials") {
          setError("البريد الإلكتروني أو كلمة المرور غير صحيحة.");
        } else if (loginError.message === "Email not confirmed") {
          setError("يرجى تأكيد بريدك الإلكتروني أولاً.");
        } else {
          setError("تعذر تسجيل الدخول. يرجى المحاولة مرة أخرى.");
        }
        return;
      }

      setSuccess("تم تسجيل الدخول بنجاح.");

      router.push("/");
      router.refresh();
    } catch {
      setError("حدث خطأ أثناء تسجيل الدخول. يرجى المحاولة مرة أخرى.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <Breadcrumb current={title} />

      <div className="bd-account">
        <div className="account-art">
          <img src="/salons0.webp" alt="" />
          <div>
            <span className="eyebrow">مجتمع تيفارا</span>
            <h2>مساحتكِ في عالم الجمال</h2>
            <p>للعميلات والصالونات وخبيرات التجميل في السعودية.</p>
          </div>
        </div>

        <section>
          <div className="eyebrow">
            <i />
            حسابات تيفارا
          </div>

          <h1>{title}</h1>

          <p>
            {register
              ? "اختاري نوع الحساب للانضمام إلى مجتمع تيفارا."
              : "أدخلي بيانات حسابكِ للمتابعة."}
          </p>

          <nav className="role-tabs" aria-label="نوع الحساب">
            {Object.entries(roles).map(([key, value]) => {
              const Icon = value.icon;

              return (
                <Link
                  key={key}
                  aria-current={key === r ? "page" : undefined}
                  href={base + "?role=" + key}
                  scroll={false}
                >
                  <Icon size={17} />
                  {value.title}
                </Link>
              );
            })}
          </nav>

          <h3>{roles[r].title}</h3>
          <p>{roles[r].description}</p>

          {register ? (
            <form
              className="account-fields"
              onSubmit={handleRegister}
            >
              <label className="bd-field">
                {r === "salon" ? "اسم المسؤول" : "الاسم الكامل"}
                <input
                  name="full_name"
                  type="text"
                  placeholder="أدخل الاسم الكامل"
                  autoComplete="name"
                  required
                />
              </label>

              {r === "salon" && (
                <label className="bd-field">
                  اسم الصالون
                  <input
                    name="salon_name"
                    type="text"
                    placeholder="اسم الصالون"
                    required
                  />
                </label>
              )}

              <label className="bd-field">
                رقم الجوال
                <input
                  name="phone"
                  type="tel"
                  placeholder="05xxxxxxxx"
                  autoComplete="tel"
                />
              </label>

              <label className="bd-field">
                المدينة
                <input
                  name="city"
                  type="text"
                  placeholder="مثال: جدة أو الرياض"
                  required
                />
              </label>

              {r === "salon" && (
                <label className="bd-field">
                  رقم السجل التجاري
                  <input
                    name="commercial_registration"
                    type="text"
                    placeholder="رقم السجل التجاري"
                  />
                </label>
              )}

              {r === "expert" && (
                <label className="bd-field">
                  التخصصات
                  <input
                    name="specialties"
                    type="text"
                    placeholder="مثال: المكياج، تصفيف الشعر"
                    required
                  />
                  <small>
                    يمكنكِ كتابة أكثر من تخصص وفصلها بفاصلة.
                  </small>
                </label>
              )}

              <label className="bd-field">
                البريد الإلكتروني
                <input
                  name="email"
                  type="email"
                  placeholder="name@example.com"
                  dir="ltr"
                  autoComplete="email"
                  required
                />
              </label>

              <label className="bd-field">
                كلمة المرور
                <input
                  name="password"
                  type="password"
                  placeholder="8 أحرف أو أرقام على الأقل"
                  dir="ltr"
                  autoComplete="new-password"
                  minLength={8}
                  required
                />
              </label>

              {error && (
                <p role="alert" className="note">
                  {error}
                </p>
              )}

              {success && (
                <p role="status" className="note">
                  {success}
                </p>
              )}

              <button
                type="submit"
                className="primary"
                disabled={loading}
              >
                <LockKeyhole size={16} />
                {loading ? "جارٍ إنشاء الحساب..." : "إنشاء حساب"}
              </button>
            </form>
          ) : (
            <form
              className="account-fields"
              onSubmit={handleLogin}
            >
              <label className="bd-field">
                البريد الإلكتروني
                <input
                  name="email"
                  type="email"
                  placeholder="name@example.com"
                  dir="ltr"
                  autoComplete="email"
                  required
                />
              </label>

              <label className="bd-field">
                كلمة المرور
                <input
                  name="password"
                  type="password"
                  placeholder="أدخلي كلمة المرور"
                  dir="ltr"
                  autoComplete="current-password"
                  required
                />
              </label>

              {error && (
                <p role="alert" className="note">
                  {error}
                </p>
              )}

              {success && (
                <p role="status" className="note">
                  {success}
                </p>
              )}

              <button
                type="submit"
                className="primary"
                disabled={loading}
              >
                <LockKeyhole size={16} />
                {loading ? "جارٍ تسجيل الدخول..." : "تسجيل الدخول"}
              </button>
            </form>
          )}

          <p className="note">
            {register
              ? "تخضع حسابات الصالونات والخبيرات للمراجعة والاعتماد قبل ظهورها في المنصة."
              : "مرحباً بعودتكِ إلى مجتمع تيفارا."}
          </p>

          <Link
            className="textlink"
            href={(register ? "/login" : "/register") + "?role=" + r}
          >
            {register
              ? "لديكِ حساب؟ تسجيل الدخول"
              : "ليس لديكِ حساب؟ إنشاء حساب"}
          </Link>
        </section>
      </div>
    </>
  );
}
