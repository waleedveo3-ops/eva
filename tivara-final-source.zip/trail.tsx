import Link from "next/link";
import { ChevronLeft } from "lucide-react";
export function Breadcrumb({
  current,
  parent,
}: {
  current: string;
  parent?: [string, string];
}) {
  return (
    <nav className="bd-trail" aria-label="مسار التنقل">
      <Link href="/">الرئيسية</Link>
      <ChevronLeft size={13} />
      {parent && (
        <>
          <Link href={parent[1]}>{parent[0]}</Link>
          <ChevronLeft size={13} />
        </>
      )}
      <span aria-current="page">{current}</span>
    </nav>
  );
}
