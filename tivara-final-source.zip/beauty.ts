export const services = [
  "الشعر",
  "المكياج",
  "الأظافر",
  "الرموش",
  "الحواجب",
  "البشرة",
  "خدمات أخرى",
];
export const salons = [
  {
    slug: "aura",
    name: "صالون أورا",
    city: "الرياض",
    area: "الياسمين",
    rating: "4.9",
    price: 120,
    services: [0, 1, 2],
    image: 0,
    bio: "مساحة هادئة في شمال الرياض تجمع بين تصفيف الشعر والمكياج والعناية بالأظافر في زيارة واحدة.",
  },
  {
    slug: "lumiere",
    name: "استوديو لوميير",
    city: "جدة",
    area: "الروضة",
    rating: "4.8",
    price: 150,
    services: [1, 3, 4],
    image: 1,
    bio: "استوديو متخصص بإطلالات المناسبات وتنسيق تفاصيل العين، من المكياج الناعم إلى تحديد الحواجب.",
  },
  {
    slug: "lavin",
    name: "صالون لافين",
    city: "الرياض",
    area: "العليا",
    rating: "4.9",
    price: 100,
    services: [0, 5, 6],
    image: 2,
    bio: "صالون يجمع بين العناية بالشعر وجلسات البشرة والاسترخاء في قلب حي العليا.",
  },
  {
    slug: "maison",
    name: "ميزون بيوتي",
    city: "جدة",
    area: "الزهراء",
    rating: "4.7",
    price: 90,
    services: [0, 2, 5],
    image: 3,
    bio: "وجهة للعناية اليومية تقدم تصفيف الشعر والمانيكير وجلسات ترطيب البشرة في أجواء هادئة.",
  },
];
export const experts = [
  {
    slug: "noura",
    name: "نورة القحطاني",
    specialty: "خبيرة مكياج العرائس",
    city: "الرياض",
    area: "الياسمين",
    rating: "4.9",
    price: 300,
    services: [1, 4],
    image: 0,
    bio: "تركز نورة على المكياج الناعم وإبراز ملامح الوجه، وتنسق مع العميلة درجات الإطلالة قبل المناسبات.",
  },
  {
    slug: "sara",
    name: "سارة الحربي",
    specialty: "مصففة شعر",
    city: "جدة",
    area: "الروضة",
    rating: "4.8",
    price: 160,
    services: [0],
    image: 1,
    bio: "تختص سارة بتصفيف الشعر المموّج والتسريحات الكلاسيكية، مع اختيار اللمسة المناسبة لطبيعة الشعر.",
  },
  {
    slug: "lina",
    name: "لينا العتيبي",
    specialty: "أخصائية عناية بالبشرة",
    city: "الرياض",
    area: "العليا",
    rating: "4.9",
    price: 180,
    services: [5, 6],
    image: 2,
    bio: "تهتم لينا بجلسات العناية والترطيب اللطيفة، وتخصص الجلسة بما يلائم روتين العميلة واحتياجاتها.",
  },
];
export type Detail = {
  title: string;
  body: string;
  image?: string;
  note?: string;
};
export type ShowDetail = (data: Detail) => void;
export type Kind = "salons" | "experts";
export type DirectoryKind = Kind | "services";
export const titles = {
  salons: "دليل الصالونات",
  experts: "دليل خبيرات التجميل",
  services: "دليل الخدمات",
};
const treatments = [
  "قص وتصفيف الشعر",
  "مكياج مناسبات",
  "مانيكير وعناية بالأظافر",
  "رفع وتجميل الرموش",
  "تنسيق الحواجب",
  "تنظيف وترطيب البشرة",
  "جلسة استرخاء",
];
function listProviders(kind: Kind) {
  return (kind === "salons" ? salons : experts).map((p) => ({
    ...p,
    kind,
    href: `/${kind}/${p.slug}`,
    photo: `/${kind}${p.image}.webp`,
    offers: p.services.map((category, index) => ({
      category: services[category],
      title: treatments[category],
      price: p.price + 40 * index,
      minutes: [60, 75, 45, 50, 30, 60, 45][category],
      photo: category === 6 ? "/salons3.webp" : `/service-${category}.webp`,
    })),
  }));
}
export const providers = [
  ...listProviders("salons"),
  ...listProviders("experts"),
];
export type Provider = (typeof providers)[number];
