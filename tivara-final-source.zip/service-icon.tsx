const paths = [
  <>
    <circle cx="10" cy="27" r="4.5" />
    <circle cx="24" cy="28" r="4.5" />
    <path d="m13 24 15-20c1 5-1 10-5 14m-2 6L8 5c0 7 3 12 9 17" />
  </>,
  <>
    <path d="M12 32h13V20H12zM14 20v-6h9v6m-8-6V8c0-2 7-7 7-4v10M12 28h13" />
  </>,
  <>
    <path d="m12 14 1-10h9l1 10m-9 1v3m7-3v3M11 19c-2 1-2 3-2 5v7q0 2 3 2h11q3 0 3-2v-7q0-4-4-5Z" />
    <path d="M13 23v5" />
  </>,
  <>
    <path d="M3 13c8 12 22 12 30-1m-26 5-3 5m9-2-2 6m8-5v6m6-8 3 6m2-10 4 4" />
  </>,
  <>
    <path d="M3 17c5-5 10-9 18-8 5 1 8 3 12 5-8-1-11-2-17 0l-11 6zm6 8q9-8 19-2m-18 3q8 4 16-2" />
  </>,
  <>
    <path d="M12 12h14v20H12zM15 12V8h8v4m-5-4V4h10v2m-13 16h8m-6 4h4" />
    <path d="m6 6 .7 2.1L9 9l-2.3.8L6 12l-.7-2.2L3 9l2.3-.9Z" />
  </>,
  <>
    <path d="m17 6 2.8 8.3L28 17l-8.2 2.8L17 28l-2.7-8.2L6 17l8.3-2.7ZM28 3l1.3 4L33 8.3l-3.7 1.2L28 13l-1.3-3.5L23 8.3 26.7 7ZM7 25l1 3 3 1-3 1-1 3-1-3-3-1 3-1Z" />
  </>,
];
export function ServiceIcon({ index }: { index: number }) {
  return (
    <svg
      width="38"
      height="38"
      viewBox="0 0 36 36"
      aria-hidden="true"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.35"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[index]}
    </svg>
  );
}
