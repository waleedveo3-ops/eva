
"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import {
  Menu,
  X,
  UserRound,
  ChevronLeft,
  LogOut,
} from "lucide-react";
import { createClient } from "@/lib/supabase-client";
import type { User } from "@supabase/supabase-js";

export function Brand() {
  return (
    <Link href="/" className="brand" aria-label="تيفارا، الرئيسية">
      <img src="/lotus.svg" alt="" width="43" height="40" />
      <span dir="ltr" className="latin">
        TIVARA
      </span>
      <i />
      تيفارا
    </Link>
  );
}

const links = [
  ["الرئيسية", "/"],
  ["الخدمات", "/services"],
  ["الصالونات", "/salons"],
  ["خبيرات التجميل", "/experts"],
  ["من نحن", "/#about"],
];

export function Navigation() {
  const [open, setOpen] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [signingOut, setSigningOut] = useState(false);

  const path = usePathname();
  const router = useRouter();

  useEffect(() => {
    const supabase = createClient();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      setLoading(false);
    });

    supabase.auth.getSession().then(({ data, error }) => {
      if (!error) {
        setUser(data.session?.user ?? null);
      }
      setLoading(false);
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  async function handleLogout() {
    setSigningOut(true);

    try {
      const supabase = createClient();
      const { error } = await supabase.auth.signOut();

      if (error) {
        console.error("Logout error:", error.message);
        setSigningOut(false);
        return;
      }

      setUser(null);
      setOpen(false);
      router.push("/");
      router.refresh();
    } catch (error) {
      console.error("Logout error:", error);
      setSigningOut(false);
    }
  }

  const displayName =
    user?.user_metadata?.full_name ||
    user?.email?.split("@")[0] ||
    "حسابي";

  const items = links.map(([label, url]) => (
    <Link
      key={url}
      aria-current={
        path === url || path.startsWith(url + "/")
          ? "page"
          : undefined
      }
      href={url}
      onClick={() => setOpen(false)}
    >
      {label}
    </Link>
  ));

  return (
    <header id="home">
      <div className="shell navrow">
        <Brand />

        <nav className="desktopnav" aria-label="التنقل الرئيسي">
          {items}
        </nav>

        <div className="account">
          {loading ? (
            <span aria-hidden="true" />
          ) : user ? (
            <>
              <Link href="/account" className="account-welcome">
                <UserRound size={16} />
                {displayName}
              </Link>

              <button
                type="button"
                className="primary"
                onClick={handleLogout}
                disabled={signingOut}
              >
                <LogOut size={16} />
                {signingOut ? "جارٍ الخروج..." : "تسجيل الخروج"}
              </button>
            </>
          ) : (
            <>
              <Link href="/login">
                <UserRound size={16} />
                تسجيل الدخول
              </Link>

              <Link href="/register" className="primary">
                إنشاء حساب
                <ChevronLeft size={16} />
              </Link>
            </>
          )}
        </div>

        <button
          className="menu"
          aria-label="القائمة"
          aria-expanded={open}
          onClick={() => setOpen(!open)}
        >
          {open ? <X /> : <Menu />}
        </button>
      </div>

      {open && (
        <nav className="mobilemenu">
          {items}

          {loading ? null : user ? (
            <>
              <span className="account-welcome">
                <UserRound size={16} />
                {displayName}
              </span>

              <button
                type="button"
                onClick={handleLogout}
                disabled={signingOut}
              >
                {signingOut ? "جارٍ الخروج..." : "تسجيل الخروج"}
              </button>
            </>
          ) : (
            <>
              <Link href="/login" onClick={() => setOpen(false)}>
                تسجيل الدخول
              </Link>

              <Link href="/register" onClick={() => setOpen(false)}>
                إنشاء حساب
              </Link>
            </>
          )}
        </nav>
      )}
    </header>
  );
}
