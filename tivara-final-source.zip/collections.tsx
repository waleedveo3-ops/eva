import {
  ArrowLeft,
  CalendarDays,
  Search,
  Heart,
  Star,
  Sparkles,
  Mail,
  Camera,
} from "lucide-react";
import { experts, type ShowDetail } from "@/lib/beauty";
import { Heading } from "./discovery";
import { Brand } from "./navigation";
export function Collections({ show }: { show: ShowDetail }) {
  return (
    <>
      <section id="experts" className="section">
        <Heading label="لمسات احترافية" title="خبيرات جمال نرشّحهن لكِ" />
        <div className="threegrid">
          {experts.map((x, i) => (
            <article className="expert" key={x.name}>
              <img src={"/experts" + i + ".webp"} loading="lazy" alt={x.name} />
              <div>
                <small>
                  {x.city} · <Star size={12} className="gold" />
                  {x.rating}
                </small>
                <h3>{x.name}</h3>
                <p>{x.specialty}</p>
                <a className="textlink" href={"/experts/" + x.slug}>
                  تفاصيل الحجز <ArrowLeft size={14} />
                </a>
              </div>
            </article>
          ))}
        </div>
      </section>
      <section className="section how" id="about">
        <Heading label="تجربة تيفارا" title="رحلتكِ إلى الجمال في ثلاث خطوات" />
        <div className="threegrid">
          {[
            [Search, "اكتشفي خدمتكِ", "اختاري الخدمة والمدينة لتجدي ما يناسبكِ."],
            [
              Heart,
              "اختاري وجهتكِ",
              "تعرّفي على الصالونات والخبيرات وقارني التفاصيل.",
            ],
            [
              CalendarDays,
              "حددي موعدكِ",
              "عند الإطلاق، ستتمكنين من اختيار موعدكِ وتأكيده.",
            ],
          ].map(([Icon, title, desc], i) => {
            const I = Icon as typeof Search;
            return (
              <div key={i} className="step">
                <span>
                  <I size={23} /> <b>0{i + 1}</b>
                </span>
                <h3>{String(title)}</h3>
                <p>{String(desc)}</p>
              </div>
            );
          })}
        </div>
      </section>
      <section className="section">
        <Heading label="جمال بقيمة أكثر" title="عروض مختارة لكِ" />
        <div className="offers">
          {["تألّقي بإطلالة جديدة", "لحظة عناية لبشرتكِ"].map((n, i) => (
            <article key={n} className="offer">
              <img
                loading="lazy"
                alt=""
                src={"/salons" + (i === 0 ? 0 : 3) + ".webp"}
              />
              <div>
                <small>خصم {i === 0 ? "٢٠" : "١٥"}٪</small>
                <h3>{n}</h3>
                <p>
                  {i === 0
                    ? "باقة قص وتصفيف الشعر · صالون أورا"
                    : "جلسة تنظيف وترطيب · ميزون بيوتي"}
                </p>
                <button
                  className="textlink"
                  onClick={() =>
                    show({
                      title: n,
                      body:
                        i === 0
                          ? "خصم توضيحي ٢٠٪ على باقة قص وتصفيف الشعر في صالون أورا بالرياض."
                          : "خصم توضيحي ١٥٪ على جلسة تنظيف وترطيب البشرة في ميزون بيوتي بجدة.",
                      note: "عرض تجريبي غير قابل للاسترداد أو الحجز.",
                    })
                  }
                >
                  تفاصيل العرض
                  <ArrowLeft size={14} />
                </button>
              </div>
            </article>
          ))}
        </div>
      </section>
      <section className="section">
        <Heading label="مجتمع تيفارا" title="من تجارب العميلات" />
        <div className="threegrid">
          {[
            [
              "ريم",
              "الرياض",
              "أحببت أن تفاصيل الخدمات والأسعار واضحة، ساعدني هذا على مقارنة الصالونات في حيّي.",
            ],
            [
              "دانا",
              "جدة",
              "جميل أن أجد خبيرات مستقلات وصالونات في مكان واحد، خصوصًا عند البحث عن مكياج للمناسبات.",
            ],
            [
              "هند",
              "الرياض",
              "أول ما يهمني هو موقع الصالون وتخصصه، وهنا أستطيع استكشاف الاثنين بسهولة.",
            ],
          ].map(([n, c, r]) => (
            <blockquote key={n}>
              <span className="stars" aria-label="خمسة نجوم">
                ★★★★★
              </span>
              <p>«{r}»</p>
              <b>{n}</b>
              <small> · {c}</small>
            </blockquote>
          ))}
        </div>
        <small className="sample">آراء توضيحية لأغراض المعاينة.</small>
      </section>
      <section className="partner section">
        <div>
          <div className="eyebrow">
            <Sparkles size={16} />
            شركاء الجمال
          </div>
          <h2>كوني جزءًا من تيفارا</h2>
          <p>لديكِ صالون أو تعملين كخبيرة مستقلة؟ عرّفي العميلات بخدماتكِ.</p>
        </div>
        <a href="/partner">
          انضمي كشريكة
          <ArrowLeft size={16} />
        </a>
      </section>
    </>
  );
}
export function Footer({ show }: { show: ShowDetail }) {
  return (
    <footer>
      <div className="shell footerrow">
        <div>
          <Brand />
          <p>وجهتكِ لاكتشاف الجمال في الرياض وجدة.</p>
        </div>
        <div>
          <h3>روابط سريعة</h3>
          <a href="/services">الخدمات</a>
          <a href="/salons">الصالونات</a>
          <a href="/experts">خبيرات التجميل</a>
          <a href="/partner">شركاء تيفارا</a>
        </div>
        <div>
          <h3>معلومات تيفارا</h3>
          {["سياسة الخصوصية", "شروط الاستخدام"].map((n, i) => (
            <button
              key={n}
              onClick={() =>
                show({
                  title: n,
                  body: i
                    ? "هذه الصفحة معاينة للتصميم. جميع الصالونات والأسعار والعروض معروضة كأمثلة، ولا تُنشئ حجزًا أو عقدًا."
                    : "لا تطلب هذه المعاينة بيانات شخصية أو معلومات دفع. تبقى اختيارات البحث والمفضلة في الصفحة ولا تُحفظ بعد إعادة تحميلها.",
                })
              }
            >
              {n}
            </button>
          ))}
        </div>
        <div>
          <h3>تواصلي معنا</h3>
          <span className="contact">
            <Mail size={15} />
            <bdi>hello@tivara.example</bdi>
          </span>
          <button
            onClick={() =>
              show({
                title: "تيفارا على إنستغرام",
                body: "سيُضاف رابط حساب تيفارا الرسمي عند الإطلاق.",
              })
            }
          >
            <Camera size={15} />
            إنستغرام
          </button>
        </div>
      </div>
      <div className="shell copyright">
        © ٢٠٢٦ تيفارا. جميع الحقوق محفوظة.{" "}
        <span>نسخة تجريبية · بيانات توضيحية</span>
      </div>
    </footer>
  );
}
