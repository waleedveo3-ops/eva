"use client";
import { useState } from "react";
import {
  ArrowLeft,
  ChevronDown,
  MapPin,
  MapPinned,
  Search,
  Sparkles,
  Star,
  Heart,
} from "lucide-react";
import { services, salons } from "@/lib/beauty";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ServiceIcon } from "./service-icon";
export function Heading({
  label,
  title,
  children,
}: {
  label: string;
  title: string;
  children?: React.ReactNode;
}) {
  return (
    <div className="sectionhead">
      <div>
        <div className="eyebrow">
          <i />
          {label}
        </div>
        <h2>{title}</h2>
      </div>
      {children}
    </div>
  );
}
function Field({
  title,
  placeholder,
  options,
  value,
  change,
  icon,
}: {
  title: string;
  placeholder: string;
  options: string[];
  value: string;
  change: (v: string) => void;
  icon: React.ReactNode;
}) {
  return (
    <label className="field">
      <span>
        {icon}
        {title}
      </span>
      <div>
        <select
          aria-label={title}
          value={value}
          onChange={(e) => change(e.target.value)}
        >
          <option value="">{placeholder}</option>
          {options.map((o) => (
            <option key={o}>{o}</option>
          ))}
        </select>
        <ChevronDown size={13} />
      </div>
    </label>
  );
}
export function Discovery() {
  const router = useRouter();
  const [service, setService] = useState(""),
    [city, setCity] = useState(""),
    [area, setArea] = useState(""),
    [query, setQuery] = useState<string[] | null>(null),
    [saved, setSaved] = useState<string[]>([]);
  const apply = (s = service, c = city, a = area) => {
    setQuery([s, c, a]);
    document.getElementById("salons")?.scrollIntoView();
  };
  const filterService = (s: string) => {
    setService(s);
    setCity("");
    setArea("");
    apply(s, "", "");
  };
  const filtered = salons.filter(
    (x) =>
      !query ||
      ((!query[0] || x.services.includes(services.indexOf(query[0]))) &&
        (!query[1] || x.city === query[1]) &&
        (!query[2] || x.area === query[2])),
  );
  return (
    <>
      <section className="hero" aria-labelledby="hero-title">
        <div className="hero-copy">
          <div className="hero-kicker">
            <Sparkles size={15} />
            وجهتكِ للجمال في السعودية
          </div>
          <h1 id="hero-title">
            جمالك يبدأ <em>من هنا</em>
          </h1>
          <p>
            اكتشفي أفضل الصالونات وخبيرات التجميل
            <br className="wide-break" /> واحجزي خدمتك بكل سهولة
          </p>
        </div>
        <div className="hero-tools">
          <form
            className="searchbox"
            onSubmit={(e) => {
              e.preventDefault();
              apply();
            }}
          >
            <Field
              title="الخدمة"
              icon={<Sparkles />}
              placeholder="اختاري الخدمة"
              options={services}
              value={service}
              change={setService}
            />
            <Field
              title="المدينة"
              icon={<MapPinned />}
              placeholder="اختاري المدينة"
              options={["الرياض", "جدة"]}
              value={city}
              change={(v) => {
                setCity(v);
                setArea("");
              }}
            />
            <Field
              title="الحي"
              icon={<MapPin />}
              placeholder="جميع الأحياء"
              options={salons
                .filter((s) => !city || city === s.city)
                .map((s) => s.area)}
              value={area}
              change={setArea}
            />
            <button className="primary searchbtn">
              <Search size={18} />
              بحث
            </button>
          </form>
          <div className="popular">
            <span>الأكثر بحثًا:</span>
            {["الشعر", "المكياج", "الأظافر"].map((s, i) => (
              <button key={s} onClick={() => filterService(s)}>
                {["تصفيف الشعر", "مكياج مناسبات", "عناية بالأظافر"][i]}
              </button>
            ))}
          </div>
        </div>
      </section>
      <section id="services" className="section">
        <Heading label="عالم الجمال" title="اكتشفي الخدمات" />
        <div className="categories">
          {services.map((s, i) => (
            <button
              key={s}
              onClick={() =>
                router.push("/services?category=" + encodeURIComponent(s))
              }
            >
              <span className="iconwell">
                <ServiceIcon index={i} />
              </span>
              {s}
            </button>
          ))}
        </div>
      </section>
      <section id="salons" className="section">
        <Heading
          label="اختيارات تيفارا"
          title={query ? "نتائج البحث عن صالونات" : "صالونات مميزة"}
        >
          <Link href="/salons" className="textlink">
            جميع الصالونات
            <ArrowLeft size={16} />
          </Link>
        </Heading>
        {query && (
          <div className="filterbar" role="status">
            <span>
              {filtered.length} نتائج ·{" "}
              {query.filter(Boolean).join("، ") || "كل الصالونات"}
            </span>
            <button
              onClick={() => {
                setQuery(null);
                setService("");
                setCity("");
                setArea("");
              }}
            >
              إزالة التصفية
            </button>
          </div>
        )}
        <div className="salongrid">
          {filtered.map((s) => (
            <article className="salon" key={s.name}>
              <div className="salonphoto">
                <img
                  loading="lazy"
                  src={"/salons" + s.image + ".webp"}
                  alt={"المساحة الداخلية في " + s.name}
                />
                <span className="rating">
                  <Star size={13} fill="currentColor" />
                  <b>{s.rating}</b>
                </span>
                <button
                  className="favorite"
                  aria-pressed={saved.includes(s.name)}
                  aria-label={"تفضيل " + s.name}
                  onClick={() =>
                    setSaved(
                      saved.includes(s.name)
                        ? saved.filter((n) => n !== s.name)
                        : [...saved, s.name],
                    )
                  }
                >
                  <Heart
                    size={17}
                    fill={saved.includes(s.name) ? "currentColor" : "none"}
                  />
                </button>
              </div>
              <div className="cardbody">
                <h3>{s.name}</h3>
                <p>
                  <MapPin size={15} />
                  {s.city}، حي {s.area}
                </p>
                <div className="cardbottom">
                  <span>
                    يبدأ من <b>{s.price} ر.س</b>
                  </span>
                  <Link
                    className="circlelink"
                    aria-label={"تفاصيل " + s.name}
                    href={"/salons/" + s.slug}
                  >
                    <ArrowLeft size={17} />
                  </Link>
                </div>
              </div>
            </article>
          ))}
        </div>
        {!filtered.length && (
          <p className="empty">
            لا توجد صالونات تطابق اختيارك. جرّبي حيًا آخر أو أزيلي التصفية.
          </p>
        )}
      </section>
    </>
  );
}
